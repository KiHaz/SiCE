# 📋 Guía de Usuario - Sistema de Almacenamiento SiCE

## 🌟 Bienvenido al Sistema de Compras Emergentes

Esta guía te ayudará a entender y utilizar todas las funcionalidades del sistema de almacenamiento de SiCE.

## 🔐 Primer Acceso

### Credenciales por Defecto
```
Usuario: admin
Contraseña: 1234
```

### Qué Sucede en el Primer Login:
1. El sistema crea automáticamente la cuenta de administrador
2. Se inicializa el almacenamiento local con datos por defecto
3. Se establece la sesión del usuario
4. Se redirige al dashboard principal

## 💾 Sistema de Almacenamiento

### Datos Almacenados Localmente:

#### 1. **Usuarios del Sistema** (`sice-users`)
- Información completa de todos los usuarios
- Datos personales, roles y permisos
- Fechas de creación, actualización y último acceso
- Estado activo/inactivo

#### 2. **Credenciales** (`sice-credentials`)
- Nombres de usuario y contraseñas
- Almacenamiento separado por seguridad
- Validación de acceso

#### 3. **Sesión Actual** (`sice-user`)
- Información del usuario logueado
- Datos de sesión activa
- Permisos y roles actuales

#### 4. **Configuración** (`sice-settings`)
- Configuraciones generales del sistema
- Preferencias de seguridad
- Opciones de notificaciones

## 👥 Gestión de Usuarios

### Roles Disponibles:

#### 🛡️ **Administrador**
- Acceso completo al sistema
- Gestión de usuarios
- Configuración del sistema
- Backup/Restore de datos
- **Color**: Verde (#52c41a)

#### 👔 **Gerente**
- Gestión de compras
- Acceso a reportes
- Gestión limitada de usuarios
- **Color**: Azul (#1890ff)

#### 👤 **Usuario**
- Acceso básico al sistema
- Compras emergentes
- Reportes de solo lectura
- **Color**: Amarillo (#faad14)

#### 👁️ **Invitado**
- Acceso de solo lectura
- Visualización de reportes
- Sin permisos de modificación
- **Color**: Gris (#8c8c8c)

### Permisos por Módulo:

#### 📋 **Gestión de Usuarios**
- Crear, editar, eliminar usuarios
- Asignar roles y permisos
- Solo disponible para administradores

#### 👥 **Gestión de Perfiles**
- Crear y gestionar perfiles
- Acceso según el rol del usuario

#### 💰 **Compras Emergentes**
- Crear y gestionar compras
- Diferentes niveles de acceso por rol

#### 📊 **Reportes y Estadísticas**
- Generar y ver reportes
- Exportar datos

#### ⚙️ **Configuración del Sistema**
- Ajustar configuraciones generales
- Solo administradores

## 🏗️ Crear Nuevos Usuarios

### Paso a Paso:

1. **Acceder a Gestión de Perfiles**
   - Desde el menú lateral, clic en "Gestión de Perfiles"

2. **Crear Nuevo Usuario**
   - Clic en "Crear Nuevo Perfil"
   - Completar el formulario:
     - Nombre de usuario (único)
     - Email (único)
     - Nombre y apellido
     - Contraseña
     - Seleccionar rol

3. **Asignar Permisos**
   - Los permisos se asignan automáticamente según el rol
   - Posibilidad de personalizar permisos específicos

4. **Guardar Usuario**
   - El sistema valida los datos
   - Crea el usuario en el almacenamiento
   - Genera credenciales de acceso

## 🛠️ Administración del Sistema

### Panel de Configuración:

#### 🌐 **Configuración General**
- Nombre del sistema
- Descripción
- Idioma y zona horaria
- Configuraciones de comportamiento

#### 🔒 **Configuración de Seguridad**
- Longitud mínima de contraseña
- Requisitos de contraseña
- Tiempo de sesión
- Máximo intentos de login

#### 🔔 **Notificaciones**
- Configurar alertas del sistema
- Notificaciones por email
- Notificaciones push

#### 💾 **Gestión de Almacenamiento**
- Estadísticas del sistema
- Backup y restore
- Funciones de mantenimiento

## 📤 Backup y Restore

### Exportar Datos:

1. **Acceder a Configuración**
   - Menú lateral > Configuración
   - Pestaña "Almacenamiento"

2. **Exportar Datos**
   - Clic en "Exportar Datos"
   - Se descarga un archivo JSON con todos los datos
   - Incluye: usuarios, credenciales, configuraciones

3. **Archivo de Backup**
   - Formato: `sice-backup-YYYY-MM-DD.json`
   - Contiene toda la información del sistema
   - Timestamp de creación

### Importar Datos:

1. **Seleccionar Archivo**
   - Clic en "Seleccionar Archivo"
   - Elegir archivo JSON de backup

2. **Proceso de Importación**
   - El sistema valida el formato
   - Reemplaza los datos actuales
   - Confirma la operación

3. **Verificación**
   - Revisar que todos los datos se importaron correctamente
   - Probar el acceso con usuarios importados

## 🔧 Funciones de Mantenimiento

### Resetear Sistema:
- Elimina todos los usuarios excepto el administrador
- Vuelve a la configuración por defecto
- Mantiene las credenciales de admin

### Limpiar Datos:
- ⚠️ **¡PELIGRO!** Elimina TODOS los datos
- Incluye la cuenta de administrador
- Requiere confirmación doble

### Estadísticas del Sistema:
- Total de usuarios registrados
- Usuarios activos/inactivos
- Fecha del último backup
- Información de almacenamiento

## 🔍 Resolución de Problemas

### Problemas Comunes:

#### No Puedo Acceder:
1. Verificar credenciales
2. Revisar si el usuario está activo
3. Comprobar el almacenamiento del navegador

#### Datos Perdidos:
1. Revisar si hay un backup disponible
2. Verificar el almacenamiento local
3. Usar función de importación

#### Problemas de Rendimiento:
1. Limpiar datos innecesarios
2. Hacer backup y resetear sistema
3. Verificar espacio en LocalStorage

## 🎯 Mejores Prácticas

### Seguridad:
- Cambiar contraseña por defecto del administrador
- Crear usuarios con roles específicos
- Hacer backups regulares
- Revisar permisos periódicamente

### Mantenimiento:
- Backup semanal de datos
- Revisar usuarios activos
- Actualizar configuraciones según necesidades
- Monitorear el espacio de almacenamiento

### Organización:
- Nomenclatura clara para usuarios
- Roles bien definidos
- Documentar cambios importantes
- Mantener datos actualizados

## 🚀 Próximos Pasos

Una vez que domines el sistema de almacenamiento, puedes:

1. **Personalizar la Interfaz**
   - Modificar colores y temas
   - Ajustar componentes

2. **Extender Funcionalidades**
   - Agregar nuevos módulos
   - Implementar funciones específicas

3. **Integrar con APIs**
   - Conectar con bases de datos externas
   - Implementar sincronización

4. **Mejorar la Seguridad**
   - Implementar encriptación
   - Agregar autenticación de dos factores

---

## 📞 Soporte

Si tienes alguna duda o problema:

1. Revisa esta guía
2. Consulta el código fuente
3. Crea un issue en el repositorio
4. Contacta al equipo de desarrollo

---

**¡Disfruta usando SiCE! 🎉**
