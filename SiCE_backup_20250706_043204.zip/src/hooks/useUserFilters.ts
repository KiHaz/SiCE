import { useState, useMemo } from 'react';
import type { User } from '../types';

/**
 * Hook para manejar búsqueda y filtrado de usuarios
 */
export const useUserFilters = (users: User[]) => {
  const [searchText, setSearchText] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Filtrar usuarios basado en los criterios
  const filteredUsers = useMemo(() => {
    return users.filter(user => {
      // Filtro de búsqueda
      const matchesSearch = searchText === '' || 
        user.firstName.toLowerCase().includes(searchText.toLowerCase()) ||
        user.lastName.toLowerCase().includes(searchText.toLowerCase()) ||
        user.email.toLowerCase().includes(searchText.toLowerCase()) ||
        user.username.toLowerCase().includes(searchText.toLowerCase());
      
      // Filtro de rol
      const matchesRole = selectedRole === 'all' || user.role.name === selectedRole;
      
      // Filtro de estado
      const matchesStatus = statusFilter === 'all' || 
        (statusFilter === 'active' && user.isActive) ||
        (statusFilter === 'inactive' && !user.isActive);
      
      return matchesSearch && matchesRole && matchesStatus;
    });
  }, [users, searchText, selectedRole, statusFilter]);

  // Estadísticas de usuarios
  const stats = useMemo(() => {
    const total = users.length;
    const active = users.filter(u => u.isActive).length;
    const inactive = users.filter(u => !u.isActive).length;
    const byRole = users.reduce((acc, user) => {
      acc[user.role.name] = (acc[user.role.name] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total,
      active,
      inactive,
      byRole
    };
  }, [users]);

  // Resetear filtros
  const resetFilters = () => {
    setSearchText('');
    setSelectedRole('all');
    setStatusFilter('all');
  };

  return {
    searchText,
    setSearchText,
    selectedRole,
    setSelectedRole,
    statusFilter,
    setStatusFilter,
    filteredUsers,
    stats,
    resetFilters
  };
};
