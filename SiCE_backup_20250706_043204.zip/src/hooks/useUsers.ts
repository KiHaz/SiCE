import { useState, useEffect, useCallback } from 'react';
import { message } from 'antd';
import type { User } from '../types';
import { userStorage } from '../services/userStorage';
import { emitUserStorageEvent, USER_STORAGE_EVENTS } from '../utils/events';

/**
 * Hook personalizado para gestionar usuarios
 * Proporciona funcionalidades de CRUD con recarga automática
 */
export const useUsers = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cargar usuarios desde el almacenamiento
  const loadUsers = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const storedUsers = userStorage.getUsers();
      setUsers(storedUsers);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al cargar usuarios';
      setError(errorMessage);
      message.error(errorMessage);
    } finally {
      setLoading(false);
    }
  }, []);

  // Actualizar un usuario
  const updateUser = useCallback(async (id: string, updates: Partial<User>) => {
    try {
      const updatedUser = userStorage.updateUser(id, updates);
      setUsers(prevUsers => 
        prevUsers.map(user => 
          user.id === id ? updatedUser : user
        )
      );
      
      // Emitir evento de actualización
      emitUserStorageEvent(USER_STORAGE_EVENTS.USER_UPDATED, { user: updatedUser });
      
      return updatedUser;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al actualizar usuario';
      setError(errorMessage);
      message.error(errorMessage);
      throw err;
    }
  }, []);

  // Eliminar un usuario
  const deleteUser = useCallback(async (id: string) => {
    try {
      const user = userStorage.getUserById(id);
      if (!user) {
        throw new Error('Usuario no encontrado');
      }
      
      userStorage.deleteUser(id);
      setUsers(prevUsers => prevUsers.filter(u => u.id !== id));
      
      // Emitir evento de eliminación
      emitUserStorageEvent(USER_STORAGE_EVENTS.USER_DELETED, { userId: id, user });
      
      message.success(`Usuario ${user.firstName} ${user.lastName} eliminado correctamente`);
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error al eliminar usuario';
      setError(errorMessage);
      message.error(errorMessage);
      return false;
    }
  }, []);

  // Obtener un usuario por ID
  const getUserById = useCallback((id: string) => {
    return users.find(user => user.id === id) || null;
  }, [users]);

  // Recargar usuarios automáticamente
  const refreshUsers = useCallback(() => {
    loadUsers();
  }, [loadUsers]);

  // Cargar usuarios al inicializar
  useEffect(() => {
    loadUsers();
  }, [loadUsers]);

  return {
    users,
    loading,
    error,
    loadUsers,
    updateUser,
    deleteUser,
    getUserById,
    refreshUsers
  };
};
