import type { User, UserRole, Permission, CreateUserForm } from '../types';

// Roles predefinidos del sistema
export const systemRoles: UserRole[] = [
  {
    id: 'admin-role',
    name: 'administrator',
    displayName: 'Administrador',
    description: 'Acceso completo al sistema con todos los permisos',
    level: 1,
    color: '#52c41a'
  },
  {
    id: 'manager-role',
    name: 'manager',
    displayName: 'Gerente',
    description: 'Acceso a gestión de compras, reportes y usuarios limitados',
    level: 2,
    color: '#1890ff'
  },
  {
    id: 'user-role',
    name: 'user',
    displayName: 'Usuario',
    description: 'Acceso básico al sistema para compras emergentes',
    level: 3,
    color: '#faad14'
  },
  {
    id: 'guest-role',
    name: 'guest',
    displayName: 'Invitado',
    description: 'Acceso de solo lectura al sistema',
    level: 4,
    color: '#8c8c8c'
  }
];

// Permisos disponibles en el sistema
export const systemPermissions: Permission[] = [
  {
    id: 'users-permission',
    name: 'users',
    displayName: 'Gestión de Usuarios',
    description: 'Crear, editar, eliminar y gestionar usuarios del sistema',
    module: 'users',
    actions: [
      { action: 'create', allowed: true },
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'delete', allowed: true },
      { action: 'manage', allowed: true }
    ]
  },
  {
    id: 'profiles-permission',
    name: 'profiles',
    displayName: 'Gestión de Perfiles',
    description: 'Crear y gestionar perfiles de usuario',
    module: 'profiles',
    actions: [
      { action: 'create', allowed: true },
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'delete', allowed: true },
      { action: 'manage', allowed: true }
    ]
  },
  {
    id: 'purchases-permission',
    name: 'purchases',
    displayName: 'Compras Emergentes',
    description: 'Gestionar procesos de compras emergentes',
    module: 'purchases',
    actions: [
      { action: 'create', allowed: true },
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'delete', allowed: false },
      { action: 'manage', allowed: true }
    ]
  },
  {
    id: 'reports-permission',
    name: 'reports',
    displayName: 'Reportes y Estadísticas',
    description: 'Ver y generar reportes del sistema',
    module: 'reports',
    actions: [
      { action: 'read', allowed: true },
      { action: 'create', allowed: true },
      { action: 'update', allowed: false },
      { action: 'delete', allowed: false },
      { action: 'manage', allowed: false }
    ]
  },
  {
    id: 'settings-permission',
    name: 'settings',
    displayName: 'Configuración del Sistema',
    description: 'Acceso a configuraciones generales del sistema',
    module: 'settings',
    actions: [
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'manage', allowed: true }
    ]
  }
];

// Función para obtener permisos por rol
export const getPermissionsByRole = (roleLevel: number): Permission[] => {
  switch (roleLevel) {
    case 1: // Administrador - Todos los permisos
      return systemPermissions;
    case 2: // Gerente - Permisos limitados
      return systemPermissions.filter(p => 
        ['purchases', 'reports', 'profiles'].includes(p.name)
      );
    case 3: // Usuario - Permisos básicos
      return systemPermissions.filter(p => 
        ['purchases', 'reports'].includes(p.name)
      ).map(p => ({
        ...p,
        actions: p.actions.filter(a => a.action === 'read' || a.action === 'create')
      }));
    case 4: // Invitado - Solo lectura
      return systemPermissions.filter(p => 
        ['reports'].includes(p.name)
      ).map(p => ({
        ...p,
        actions: [{ action: 'read', allowed: true }]
      }));
    default:
      return [];
  }
};

// Usuario administrador por defecto
export const defaultAdminUser: User = {
  id: 'admin-user',
  username: 'admin',
  email: 'admin@sice.com',
  firstName: 'Administrador',
  lastName: 'del Sistema',
  role: systemRoles[0], // Rol de administrador
  permissions: getPermissionsByRole(1),
  avatar: undefined,
  isActive: true,
  createdAt: new Date('2024-01-01'),
  updatedAt: new Date(),
  lastLogin: new Date()
};

// Credenciales por defecto
export const defaultCredentials = {
  username: 'admin',
  password: '1234'
};

// Clase para gestionar el almacenamiento de usuarios
export class UserStorageManager {
  private static instance: UserStorageManager;
  private readonly STORAGE_KEY = 'sice-users';
  private readonly CREDENTIALS_KEY = 'sice-credentials';

  private constructor() {}

  public static getInstance(): UserStorageManager {
    if (!UserStorageManager.instance) {
      UserStorageManager.instance = new UserStorageManager();
    }
    return UserStorageManager.instance;
  }

  // Obtener todos los usuarios
  public getUsers(): User[] {
    try {
      const storedUsers = localStorage.getItem(this.STORAGE_KEY);
      if (storedUsers) {
        const users = JSON.parse(storedUsers);
        // Convertir strings de fecha a objetos Date
        return users.map((user: any) => ({
          ...user,
          createdAt: new Date(user.createdAt),
          updatedAt: new Date(user.updatedAt),
          lastLogin: user.lastLogin ? new Date(user.lastLogin) : undefined
        }));
      }
      // Si no hay usuarios guardados, retornar solo el admin por defecto
      this.saveUsers([defaultAdminUser]);
      return [defaultAdminUser];
    } catch (error) {
      console.error('Error al cargar usuarios:', error);
      return [defaultAdminUser];
    }
  }

  // Guardar usuarios
  public saveUsers(users: User[]): void {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(users));
    } catch (error) {
      console.error('Error al guardar usuarios:', error);
    }
  }

  // Obtener usuario por ID
  public getUserById(id: string): User | undefined {
    const users = this.getUsers();
    return users.find(user => user.id === id);
  }

  // Obtener usuario por username
  public getUserByUsername(username: string): User | undefined {
    const users = this.getUsers();
    return users.find(user => user.username === username);
  }

  // Crear nuevo usuario
  public createUser(userData: CreateUserForm): User {
    const users = this.getUsers();
    
    // Verificar si el usuario ya existe
    if (users.find(u => u.username === userData.username || u.email === userData.email)) {
      throw new Error('El usuario o email ya existe');
    }

    // Obtener el rol seleccionado
    const selectedRole = systemRoles.find(r => r.id === userData.roleId);
    if (!selectedRole) {
      throw new Error('Rol no válido');
    }

    // Crear nuevo usuario
    const newUser: User = {
      id: `user-${Date.now()}`,
      username: userData.username,
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      role: selectedRole,
      permissions: getPermissionsByRole(selectedRole.level),
      avatar: undefined,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastLogin: undefined
    };

    // Guardar credenciales
    this.saveCredentials(userData.username, userData.password);

    // Agregar usuario a la lista y guardar
    users.push(newUser);
    this.saveUsers(users);

    return newUser;
  }

  // Actualizar usuario
  public updateUser(id: string, updates: Partial<User>): User {
    const users = this.getUsers();
    const userIndex = users.findIndex(u => u.id === id);
    
    if (userIndex === -1) {
      throw new Error('Usuario no encontrado');
    }

    const updatedUser = {
      ...users[userIndex],
      ...updates,
      updatedAt: new Date()
    };

    users[userIndex] = updatedUser;
    this.saveUsers(users);

    return updatedUser;
  }

  // Eliminar usuario
  public deleteUser(id: string): boolean {
    const users = this.getUsers();
    const user = users.find(u => u.id === id);
    
    if (!user) {
      throw new Error('Usuario no encontrado');
    }

    // No permitir eliminar el administrador principal
    if (user.username === 'admin') {
      throw new Error('No se puede eliminar el administrador principal');
    }

    const filteredUsers = users.filter(u => u.id !== id);
    this.saveUsers(filteredUsers);

    // Eliminar credenciales
    this.deleteCredentials(user.username);

    return true;
  }

  // Gestión de credenciales
  private getCredentials(): Record<string, string> {
    try {
      const stored = localStorage.getItem(this.CREDENTIALS_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
      // Credenciales por defecto
      const defaultCreds = { [defaultCredentials.username]: defaultCredentials.password };
      this.saveAllCredentials(defaultCreds);
      return defaultCreds;
    } catch (error) {
      console.error('Error al cargar credenciales:', error);
      return { [defaultCredentials.username]: defaultCredentials.password };
    }
  }

  private saveAllCredentials(credentials: Record<string, string>): void {
    try {
      localStorage.setItem(this.CREDENTIALS_KEY, JSON.stringify(credentials));
    } catch (error) {
      console.error('Error al guardar credenciales:', error);
    }
  }

  public saveCredentials(username: string, password: string): void {
    const credentials = this.getCredentials();
    credentials[username] = password;
    this.saveAllCredentials(credentials);
  }

  public validateCredentials(username: string, password: string): boolean {
    const credentials = this.getCredentials();
    return credentials[username] === password;
  }

  public deleteCredentials(username: string): void {
    const credentials = this.getCredentials();
    delete credentials[username];
    this.saveAllCredentials(credentials);
  }

  public changePassword(username: string, newPassword: string): void {
    const user = this.getUserByUsername(username);
    if (!user) {
      throw new Error('Usuario no encontrado');
    }
    this.saveCredentials(username, newPassword);
  }

  // Actualizar último login
  public updateLastLogin(username: string): void {
    const users = this.getUsers();
    const userIndex = users.findIndex(u => u.username === username);
    
    if (userIndex !== -1) {
      users[userIndex].lastLogin = new Date();
      this.saveUsers(users);
    }
  }

  // Limpiar todo el almacenamiento (para desarrollo/testing)
  public clearAll(): void {
    localStorage.removeItem(this.STORAGE_KEY);
    localStorage.removeItem(this.CREDENTIALS_KEY);
  }

  // Resetear a valores por defecto
  public resetToDefaults(): void {
    this.clearAll();
    this.saveUsers([defaultAdminUser]);
    this.saveCredentials(defaultCredentials.username, defaultCredentials.password);
  }

  // Exportar datos (para backup)
  public exportData(): string {
    return JSON.stringify({
      users: this.getUsers(),
      credentials: this.getCredentials(),
      timestamp: new Date().toISOString()
    });
  }

  // Importar datos (para restore)
  public importData(data: string): void {
    try {
      const parsed = JSON.parse(data);
      if (parsed.users && parsed.credentials) {
        this.saveUsers(parsed.users);
        this.saveAllCredentials(parsed.credentials);
      } else {
        throw new Error('Formato de datos inválido');
      }
    } catch (error) {
      console.error('Error al importar datos:', error);
      throw new Error('Error al importar datos: formato inválido');
    }
  }
}

// Exportar instancia singleton
export const userStorage = UserStorageManager.getInstance();
