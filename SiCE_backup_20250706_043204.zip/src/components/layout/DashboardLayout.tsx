import React from 'react';
import { Layout, Menu, Avatar, Dropdown, Space, Typography } from 'antd';
import { UserOutlined, LogoutOutlined, SettingOutlined, DashboardOutlined, TeamOutlined } from '@ant-design/icons';
import { useNavigate, useLocation } from 'react-router-dom';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import { useAuth } from '../../contexts/AuthContext';

const { Header, Sider, Content } = Layout;
const { Title } = Typography;

const StyledLayout = styled(Layout)`
  min-height: 100vh;
  background: linear-gradient(135deg, #ffffff 0%, #f6ffed 50%, #d9f7be 100%);
`;

const StyledHeader = styled(Header)`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(82, 196, 26, 0.1);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  padding: 0 16px;
  padding-left: 88px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 999;
  height: 64px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  @media (max-width: 1200px) {
    padding-left: 88px;
    padding-right: 12px;
  }
  
  @media (max-width: 992px) {
    padding-left: 88px;
    padding-right: 8px;
  }
  
  @media (max-width: 768px) {
    padding-left: 12px;
    padding-right: 8px;
  }
  
  @media (max-width: 576px) {
    padding-left: 8px;
    padding-right: 4px;
  }
`;

const StyledSider = styled(Sider)`
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-right: 1px solid rgba(82, 196, 26, 0.1);
  box-shadow: 2px 0 8px rgba(0, 0, 0, 0.05);
  position: fixed;
  height: 100vh;
  left: 0;
  top: 0;
  z-index: 1000;
  overflow: hidden;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  &.collapsed {
    width: 80px !important;
    min-width: 80px !important;
    max-width: 80px !important;
    
    .ant-menu-item-icon {
      margin-right: 0;
    }
    
    .ant-menu-title-content {
      opacity: 0;
      width: 0;
      overflow: hidden;
    }
  }
  
  &.collapsed:hover {
    width: 256px !important;
    min-width: 256px !important;
    max-width: 256px !important;
    box-shadow: 4px 0 16px rgba(0, 0, 0, 0.1);
    
    .ant-menu-item-icon {
      margin-right: 12px;
    }
    
    .ant-menu-title-content {
      opacity: 1;
      width: auto;
      overflow: visible;
    }
    
    .logo-text {
      opacity: 1;
      transform: translateX(0);
    }
  }
  
  .ant-layout-sider-trigger {
    display: none;
  }
  
  .ant-layout-sider-children {
    overflow-y: auto;
    overflow-x: hidden;
  }
  
  .ant-menu {
    background: transparent;
    border: none;
    padding: 0 4px;
    
    .ant-menu-item {
      margin: 4px 4px;
      border-radius: 8px;
      height: 48px;
      line-height: 48px;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      padding: 0 12px;
      
      &:hover {
        background: rgba(82, 196, 26, 0.1);
        transform: translateX(4px);
      }
      
      &.ant-menu-item-selected {
        background: linear-gradient(45deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
        color: #52c41a;
        
        &::after {
          border-right: 3px solid #52c41a;
        }
      }
      
      .ant-menu-item-icon {
        font-size: 18px;
        margin-right: 12px;
        transition: all 0.3s ease;
        flex-shrink: 0;
        min-width: 18px;
        text-align: center;
      }
      
      .ant-menu-title-content {
        font-weight: 500;
        transition: all 0.3s ease;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      
      /* Eliminar tooltips */
      .ant-tooltip {
        display: none !important;
      }
    }
  }
  
  /* Eliminar tooltips globalmente en el sidebar */
  .ant-tooltip {
    display: none !important;
  }
  
  @media (max-width: 768px) {
    &.collapsed {
      width: 0px !important;
      min-width: 0px !important;
      max-width: 0px !important;
    }
    
    &.collapsed:hover {
      width: 256px !important;
      min-width: 256px !important;
      max-width: 256px !important;
    }
  }
`;

const StyledContent = styled(Content)`
  margin-left: 80px;
  margin-top: 64px;
  padding: 24px;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-radius: 12px;
  border: 1px solid rgba(82, 196, 26, 0.1);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  min-height: calc(100vh - 88px);
  margin-right: 24px;
  margin-bottom: 24px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  
  @media (max-width: 768px) {
    margin-left: 24px;
  }
`;

const LogoContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  margin-right: 16px;
  
  @media (max-width: 768px) {
    gap: 6px;
    margin-right: 12px;
  }
  
  @media (max-width: 576px) {
    gap: 4px;
    margin-right: 8px;
  }
`;

const LogoText = styled(Title)`
  margin: 0 !important;
  background: linear-gradient(45deg, #52c41a, #73d13d);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  font-weight: 700;
  font-size: 16px;
  white-space: nowrap;
  line-height: 1.2;
  
  @media (max-width: 1200px) {
    font-size: 15px;
  }
  
  @media (max-width: 992px) {
    font-size: 14px;
  }
  
  @media (max-width: 768px) {
    font-size: 13px;
  }
  
  @media (max-width: 576px) {
    font-size: 12px;
  }
`;

const SidebarLogo = styled.div`
  padding: 16px 12px;
  text-align: center;
  border-bottom: 1px solid rgba(82, 196, 26, 0.1);
  
  .logo-icon {
    font-size: 24px;
    color: #52c41a;
    margin-bottom: 8px;
    display: block;
  }
  
  .logo-text {
    font-size: 16px;
    font-weight: 700;
    background: linear-gradient(45deg, #52c41a, #73d13d);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    opacity: 0;
    transform: translateX(-10px);
    transition: all 0.3s ease;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  &:hover .logo-text {
    opacity: 1;
    transform: translateX(0);
  }
`;

const UserInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  min-width: fit-content;
  
  @media (max-width: 768px) {
    gap: 6px;
  }
  
  @media (max-width: 576px) {
    gap: 4px;
  }
`;

const UserName = styled.span`
  font-weight: 500;
  color: #262626;
  white-space: nowrap;
  font-size: 14px;
  line-height: 1.2;
  min-width: fit-content;
  
  @media (max-width: 1200px) {
    font-size: 13px;
  }
  
  @media (max-width: 992px) {
    font-size: 13px;
  }
  
  @media (max-width: 768px) {
    font-size: 12px;
  }
  
  @media (max-width: 576px) {
    font-size: 11px;
  }
`;

const UserRole = styled.span`
  font-size: 11px;
  color: #52c41a;
  background: rgba(82, 196, 26, 0.1);
  padding: 2px 6px;
  border-radius: 10px;
  white-space: nowrap;
  line-height: 1.2;
  
  @media (max-width: 768px) {
    font-size: 10px;
    padding: 1px 4px;
  }
`;

interface DashboardLayoutProps {
  children: React.ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const menuItems = [
    {
      key: '/dashboard',
      icon: <DashboardOutlined />,
      label: 'Dashboard',
      title: '', // Eliminar tooltip
      onClick: () => navigate('/dashboard')
    },
    {
      key: '/profiles',
      icon: <TeamOutlined />,
      label: 'Gestión de Perfiles',
      title: '', // Eliminar tooltip
      onClick: () => navigate('/profiles')
    },
    {
      key: '/settings',
      icon: <SettingOutlined />,
      label: 'Configuración',
      title: '', // Eliminar tooltip
      onClick: () => navigate('/settings')
    }
  ];

  const userMenuItems = [
    {
      key: 'profile',
      icon: <UserOutlined />,
      label: 'Mi Perfil',
      onClick: () => navigate('/profile')
    },
    {
      key: 'settings',
      icon: <SettingOutlined />,
      label: 'Configuración',
      onClick: () => navigate('/settings')
    },
    {
      type: 'divider' as const
    },
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: 'Cerrar Sesión',
      onClick: logout
    }
  ];

  return (
    <StyledLayout>
      <StyledSider
        width={256}
        collapsedWidth={80}
        collapsed={true}
        className="collapsed"
        breakpoint="lg"
        onBreakpoint={(broken) => {
          console.log(broken);
        }}
      >
        <SidebarLogo>
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <DashboardOutlined className="logo-icon" />
            <div className="logo-text">SiCE</div>
          </motion.div>
        </SidebarLogo>
        
        <Menu
          theme="light"
          mode="inline"
          selectedKeys={[location.pathname]}
          items={menuItems}
        />
      </StyledSider>
      
      <Layout>
        <StyledHeader>
          <LogoContainer>
            <LogoText level={4}>Sistema de Compras Emergentes</LogoText>
          </LogoContainer>
          
          <UserInfo>
            <Space size={8}>
              <div style={{ 
                textAlign: 'right', 
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'flex-end',
                minWidth: 'fit-content'
              }}>
                <UserName>{user?.firstName} {user?.lastName}</UserName>
                <UserRole>{user?.role.displayName}</UserRole>
              </div>
              <Dropdown
                menu={{ items: userMenuItems }}
                placement="bottomRight"
                trigger={['click']}
              >
                <Avatar
                  size="large"
                  icon={<UserOutlined />}
                  style={{
                    background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                    cursor: 'pointer',
                    border: '2px solid rgba(82, 196, 26, 0.2)',
                    flexShrink: 0
                  }}
                />
              </Dropdown>
            </Space>
          </UserInfo>
        </StyledHeader>
        
        <StyledContent>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {children}
          </motion.div>
        </StyledContent>
      </Layout>
    </StyledLayout>
  );
};

export default DashboardLayout;
