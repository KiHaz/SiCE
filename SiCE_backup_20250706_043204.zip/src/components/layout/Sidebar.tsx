import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  TeamOutlined, 
  SettingOutlined, 
  DashboardOutlined,
  ShoppingCartOutlined
} from '@ant-design/icons';
import styled from '@emotion/styled';

const SidebarContainer = styled.div`
  height: 100%;
  background: linear-gradient(135deg, #ffffff 0%, #f6ffed 50%, #d9f7be 100%);
  border-radius: 12px;
  margin: 8px;
  overflow-y: auto;
`;

const MenuItem = styled.div<{ isActive?: boolean }>`
  display: flex;
  align-items: center;
  padding: 16px 24px;
  cursor: pointer;
  font-size: 16px;
  transition: all 0.3s ease;
  margin: 4px 8px;
  border-radius: 8px;
  background: ${props => props.isActive 
    ? 'linear-gradient(135deg, rgba(82, 196, 26, 0.15), rgba(115, 209, 61, 0.15))'
    : 'transparent'
  };
  color: ${props => props.isActive ? '#52c41a' : '#262626'};
  font-weight: ${props => props.isActive ? '600' : '400'};
  
  &:hover {
    background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  }
  
  .menu-icon {
    margin-right: 12px;
    font-size: 18px;
  }
  
  a {
    color: inherit;
    text-decoration: none;
    flex: 1;
  }
`;

const Sidebar: React.FC = () => {
  const location = useLocation();

  return (
    <SidebarContainer>
      <MenuItem isActive={location.pathname === '/dashboard'}>
        <DashboardOutlined className="menu-icon" />
        <Link to="/dashboard">Dashboard</Link>
      </MenuItem>

      <MenuItem isActive={location.pathname === '/emergency-purchases'}>
        <ShoppingCartOutlined className="menu-icon" />
        <Link to="/emergency-purchases">SCE - Solicitud de Compras</Link>
      </MenuItem>

      <MenuItem isActive={location.pathname === '/profiles'}>
        <TeamOutlined className="menu-icon" />
        <Link to="/profiles">Gestión de Perfiles</Link>
      </MenuItem>

      <MenuItem isActive={location.pathname === '/settings'}>
        <SettingOutlined className="menu-icon" />
        <Link to="/settings">Configuración</Link>
      </MenuItem>
    </SidebarContainer>
  );
};

export default Sidebar;