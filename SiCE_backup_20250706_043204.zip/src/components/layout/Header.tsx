import React from 'react';
import { Layout, Typography, Button, Space, Avatar } from 'antd';
import { UserOutlined, LogoutOutlined } from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';

const { Header: AntHeader } = Layout;
const { Title } = Typography;

const StyledHeader = styled(AntHeader)`
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(82, 196, 26, 0.1);
  padding: 0 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
`;

const Header: React.FC = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <StyledHeader>
        <Title level={3} style={{ margin: 0, color: '#52c41a' }}>
          SiCE - Sistema de Compras Emergentes
        </Title>
        <Space>
          <Avatar icon={<UserOutlined />} />
          <Button 
            type="text" 
            icon={<LogoutOutlined />}
            style={{ color: '#52c41a' }}
          >
            Cerrar Sesión
          </Button>
        </Space>
      </StyledHeader>
    </motion.div>
  );
};

export default Header;
