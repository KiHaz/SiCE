import React from 'react';
import { Card, Row, Col, Typography, Button, Space, Statistic, Badge } from 'antd';
import { ShoppingCartOutlined, UserOutlined, FileTextOutlined, CheckCircleOutlined, RiseOutlined } from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

const { Title, Paragraph } = Typography;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  }
`;

const StatisticCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease;
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  }
`;

const QuickActions = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 16px;
  margin-top: 24px;
`;

const ActionCard = styled.div`
  padding: 24px;
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease;
  cursor: pointer;
  
  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  }
`;

const ActionIcon = styled.div`
  font-size: 48px;
  margin-bottom: 16px;
  color: #52c41a;
`;

const Dashboard: React.FC = () => {
  const navigate = useNavigate();

  const statisticsData = [
    { title: 'Solicitudes Totales', value: 0, icon: <ShoppingCartOutlined />, color: '#52c41a' },
    { title: 'Usuarios Activos', value: 0, icon: <UserOutlined />, color: '#1890ff' },
    { title: 'Compras Aprobadas', value: 0, icon: <CheckCircleOutlined />, color: '#faad14' },
    { title: 'En Proceso', value: 0, icon: <RiseOutlined />, color: '#f5222d' },
  ];

  const quickActions = [
    {
      title: 'Nueva Solicitud',
      description: 'Crear nueva solicitud de compra emergente',
      icon: <ShoppingCartOutlined />,
      action: () => navigate('/emergency-purchases')
    },
    {
      title: 'Ver Usuarios',
      description: 'Gestionar usuarios del sistema',
      icon: <UserOutlined />,
      action: () => navigate('/profiles')
    },
    {
      title: 'Mi Perfil',
      description: 'Ver y editar información personal',
      icon: <FileTextOutlined />,
      action: () => navigate('/profile')
    }
  ];

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Title level={2} style={{ color: '#52c41a', marginBottom: '24px' }}>
          Bienvenido al Dashboard
        </Title>
        <Paragraph style={{ fontSize: '16px', color: '#595959', marginBottom: '32px' }}>
          Acceso rápido a las funcionalidades principales del sistema
        </Paragraph>
      </motion.div>

      <Row gutter={[24, 24]}>
        <Col xs={24} md={8}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <StyledCard>
              <div style={{ textAlign: 'center', padding: '24px' }}>
                <ShoppingCartOutlined 
                  style={{ 
                    fontSize: '48px', 
                    color: '#52c41a',
                    marginBottom: '16px'
                  }} 
                />
                <Title level={4} style={{ color: '#262626' }}>
                  Solicitud de Compras
                </Title>
                <Paragraph style={{ color: '#8c8c8c', marginBottom: '24px' }}>
                  Crear nueva solicitud de compra emergente
                </Paragraph>
                <Button
                  type="primary"
                  size="large"
                  onClick={() => navigate('/emergency-purchases')}
                  style={{
                    background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                    border: 'none',
                    borderRadius: '8px',
                    width: '100%'
                  }}
                >
                  Ir a SCE
                </Button>
              </div>
            </StyledCard>
          </motion.div>
        </Col>

        <Col xs={24} md={8}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <StyledCard>
              <div style={{ textAlign: 'center', padding: '24px' }}>
                <UserOutlined 
                  style={{ 
                    fontSize: '48px', 
                    color: '#1890ff',
                    marginBottom: '16px'
                  }} 
                />
                <Title level={4} style={{ color: '#262626' }}>
                  Gestión de Usuarios
                </Title>
                <Paragraph style={{ color: '#8c8c8c', marginBottom: '24px' }}>
                  Administrar usuarios del sistema
                </Paragraph>
                <Button
                  type="primary"
                  size="large"
                  onClick={() => navigate('/profiles')}
                  style={{
                    background: 'linear-gradient(45deg, #1890ff, #40a9ff)',
                    border: 'none',
                    borderRadius: '8px',
                    width: '100%'
                  }}
                >
                  Ver Usuarios
                </Button>
              </div>
            </StyledCard>
          </motion.div>
        </Col>

        <Col xs={24} md={8}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <StyledCard>
              <div style={{ textAlign: 'center', padding: '24px' }}>
                <FileTextOutlined 
                  style={{ 
                    fontSize: '48px', 
                    color: '#faad14',
                    marginBottom: '16px'
                  }} 
                />
                <Title level={4} style={{ color: '#262626' }}>
                  Mi Perfil
                </Title>
                <Paragraph style={{ color: '#8c8c8c', marginBottom: '24px' }}>
                  Ver y editar información personal
                </Paragraph>
                <Button
                  type="primary"
                  size="large"
                  onClick={() => navigate('/profile')}
                  style={{
                    background: 'linear-gradient(45deg, #faad14, #ffc53d)',
                    border: 'none',
                    borderRadius: '8px',
                    width: '100%'
                  }}
                >
                  Ver Perfil
                </Button>
              </div>
            </StyledCard>
          </motion.div>
        </Col>
      </Row>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Row gutter={[16, 16]} style={{ marginTop: '24px' }}>
          {statisticsData.map((stat, index) => (
            <Col xs={12} sm={12} md={6} lg={6} key={index}>
              <StatisticCard>
                <Statistic
                  title={stat.title}
                  value={stat.value}
                  prefix={stat.icon}
                  valueStyle={{ color: stat.color }}
                />
              </StatisticCard>
            </Col>
          ))}
        </Row>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <Title level={3} style={{ marginTop: '32px', color: '#52c41a' }}>
          Acciones Rápidas
        </Title>
        <QuickActions>
          {quickActions.map((action, index) => (
            <ActionCard key={index} onClick={action.action}>
              <ActionIcon>
                {action.icon}
              </ActionIcon>
              <Title level={4} style={{ margin: '0 0 8px 0', color: '#262626' }}>
                {action.title}
              </Title>
              <Paragraph style={{ margin: 0, color: '#595959' }}>
                {action.description}
              </Paragraph>
            </ActionCard>
          ))}
        </QuickActions>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <Row gutter={[16, 16]} style={{ marginTop: '32px' }}>
          <Col xs={24} md={12}>
            <StyledCard 
              title="Actividad Reciente"
              extra={<RiseOutlined style={{ color: '#52c41a' }} />}
            >
              <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                <div style={{ textAlign: 'center', padding: '40px 0' }}>
                  <CheckCircleOutlined style={{ fontSize: '48px', color: '#d9d9d9' }} />
                  <Paragraph style={{ marginTop: '16px', color: '#8c8c8c' }}>
                    No hay actividad reciente
                  </Paragraph>
                </div>
              </Space>
            </StyledCard>
          </Col>
          <Col xs={24} md={12}>
            <StyledCard 
              title="Notificaciones"
              extra={<Badge count={0} />}
            >
              <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                <div style={{ textAlign: 'center', padding: '40px 0' }}>
                  <CheckCircleOutlined style={{ fontSize: '48px', color: '#d9d9d9' }} />
                  <Paragraph style={{ marginTop: '16px', color: '#8c8c8c' }}>
                    No hay notificaciones
                  </Paragraph>
                </div>
              </Space>
            </StyledCard>
          </Col>
        </Row>
      </motion.div>
    </div>
  );
};

export default Dashboard;
