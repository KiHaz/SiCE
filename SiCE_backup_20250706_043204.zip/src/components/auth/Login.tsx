import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Form, Input, Button, Card, Typography, Space, Divider, message } from 'antd';
import { UserOutlined, LockOutlined, LoginOutlined, EyeInvisibleOutlined, EyeTwoTone } from '@ant-design/icons';
import styled from '@emotion/styled';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const { Title, Text } = Typography;

// Styled components
const LoginContainer = styled.div`
  width: 100vw;
  height: 100vh;
  min-height: 100vh;
  max-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #ffffff 0%, #f6ffed 50%, #d9f7be 100%);
  padding: 16px;
  position: fixed;
  top: 0;
  left: 0;
  overflow: hidden;
  box-sizing: border-box;

  /* Responsive breakpoints */
  @media (min-width: 576px) {
    padding: 24px;
  }

  @media (min-width: 768px) {
    padding: 32px;
  }

  @media (min-width: 1024px) {
    padding: 40px;
  }

  &::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(82, 196, 26, 0.1) 0%, transparent 70%);
    animation: float 20s ease-in-out infinite;
  }

  @keyframes float {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    50% { transform: translateY(-20px) rotate(180deg); }
  }
`;

const LoginCard = styled(Card)`
  width: 100%;
  max-width: 400px;
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(255, 255, 255, 0.2);
  position: relative;
  z-index: 1;

  .ant-card-body {
    padding: 24px 16px;
  }

  /* Responsive breakpoints */
  @media (min-width: 375px) {
    max-width: 360px;
    .ant-card-body {
      padding: 32px 24px;
    }
  }

  @media (min-width: 576px) {
    max-width: 420px;
    .ant-card-body {
      padding: 40px 32px;
    }
  }

  @media (min-width: 768px) {
    max-width: 450px;
    .ant-card-body {
      padding: 48px 40px;
    }
  }

  @media (min-width: 1024px) {
    max-width: 480px;
    .ant-card-body {
      padding: 56px 48px;
    }
  }

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #52c41a, #73d13d, #95de64);
    border-radius: 16px 16px 0 0;
  }
`;

const LogoContainer = styled.div`
  text-align: center;
  margin-bottom: 24px;

  /* Responsive breakpoints */
  @media (min-width: 576px) {
    margin-bottom: 32px;
  }

  @media (min-width: 768px) {
    margin-bottom: 40px;
  }
`;

const Logo = styled.div`
  width: 64px;
  height: 64px;
  background: linear-gradient(135deg, #52c41a, #73d13d);
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 12px;
  font-size: 24px;
  font-weight: bold;
  color: white;
  box-shadow: 0 4px 16px rgba(82, 196, 26, 0.3);
  position: relative;
  overflow: hidden;

  /* Responsive breakpoints */
  @media (min-width: 375px) {
    width: 72px;
    height: 72px;
    font-size: 28px;
    margin-bottom: 16px;
  }

  @media (min-width: 576px) {
    width: 80px;
    height: 80px;
    font-size: 32px;
    border-radius: 20px;
  }

  @media (min-width: 768px) {
    width: 88px;
    height: 88px;
    font-size: 36px;
    border-radius: 22px;
  }

  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s;
  }

  &:hover::before {
    left: 100%;
  }
`;

const StyledForm = styled(Form)`
  .ant-form-item {
    margin-bottom: 16px;
  }

  /* Responsive breakpoints */
  @media (min-width: 576px) {
    .ant-form-item {
      margin-bottom: 20px;
    }
  }

  @media (min-width: 768px) {
    .ant-form-item {
      margin-bottom: 24px;
    }
  }

  .ant-input-affix-wrapper {
    border-radius: 12px;
    padding: 10px 12px;
    border: 2px solid #f0f0f0;
    transition: all 0.3s ease;

    /* Responsive breakpoints */
    @media (min-width: 576px) {
      padding: 12px 16px;
    }

    @media (min-width: 768px) {
      padding: 14px 18px;
    }

    &:hover {
      border-color: #73d13d;
      box-shadow: 0 0 0 2px rgba(82, 196, 26, 0.1);
    }

    &:focus,
    &.ant-input-affix-wrapper-focused {
      border-color: #52c41a;
      box-shadow: 0 0 0 2px rgba(82, 196, 26, 0.2);
    }
  }

  .ant-input {
    border: none;
    padding: 0;
    font-size: 14px;

    /* Responsive breakpoints */
    @media (min-width: 576px) {
      font-size: 15px;
    }

    @media (min-width: 768px) {
      font-size: 16px;
    }

    &:focus {
      box-shadow: none;
    }
  }
`;

const LoginButton = styled(Button)`
  width: 100%;
  height: 44px;
  border-radius: 12px;
  font-size: 14px;
  font-weight: 600;
  background: linear-gradient(135deg, #52c41a, #73d13d);
  border: none;
  box-shadow: 0 4px 16px rgba(82, 196, 26, 0.3);
  transition: all 0.3s ease;

  /* Responsive breakpoints */
  @media (min-width: 576px) {
    height: 48px;
    font-size: 15px;
  }

  @media (min-width: 768px) {
    height: 52px;
    font-size: 16px;
  }

  @media (min-width: 1024px) {
    height: 56px;
    font-size: 17px;
  }

  &:hover {
    background: linear-gradient(135deg, #73d13d, #95de64);
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(82, 196, 26, 0.4);
  }

  &:active {
    transform: translateY(0);
  }

  &:disabled {
    background: #d9d9d9;
    transform: none;
    box-shadow: none;
  }
`;

const FloatingElement = styled(motion.div)`
  position: absolute;
  border-radius: 50%;
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  
  /* Hide decorative elements on very small screens */
  @media (max-width: 480px) {
    display: none;
  }
  
  /* Reduce size on mobile */
  @media (min-width: 481px) and (max-width: 768px) {
    transform: scale(0.7);
  }
  
  /* Normal size on tablets and up */
  @media (min-width: 769px) {
    transform: scale(1);
  }
`;

const ResponsiveTitle = styled(Title)`
  &.ant-typography {
    font-size: 20px !important;
    margin-bottom: 8px !important;
    color: #262626 !important;
    
    /* Responsive breakpoints */
    @media (min-width: 375px) {
      font-size: 22px !important;
    }
    
    @media (min-width: 576px) {
      font-size: 24px !important;
    }
    
    @media (min-width: 768px) {
      font-size: 26px !important;
    }
    
    @media (min-width: 1024px) {
      font-size: 28px !important;
    }
  }
`;

const ResponsiveText = styled(Text)`
  &.ant-typography {
    font-size: 13px !important;
    
    /* Responsive breakpoints */
    @media (min-width: 375px) {
      font-size: 14px !important;
    }
    
    @media (min-width: 576px) {
      font-size: 15px !important;
    }
    
    @media (min-width: 768px) {
      font-size: 16px !important;
    }
  }
`;

const ResponsiveDivider = styled(Divider)`
  margin: 16px 0 !important;
  
  /* Responsive breakpoints */
  @media (min-width: 576px) {
    margin: 20px 0 !important;
  }
  
  @media (min-width: 768px) {
    margin: 24px 0 !important;
  }
`;

interface LoginFormData {
  username: string;
  password: string;
}

const Login: React.FC = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = async (values: LoginFormData) => {
    setLoading(true);
    try {
      const success = await login(values.username, values.password);
      
      if (success) {
        message.success('¡Inicio de sesión exitoso!');
        navigate('/dashboard');
      } else {
        message.error('Usuario o contraseña incorrectos');
      }
    } catch (error) {
      message.error('Error al iniciar sesión');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFormFinish = (values: unknown) => {
    handleLogin(values as LoginFormData);
  };

  return (
    <LoginContainer>
      {/* Elementos flotantes decorativos */}
      <FloatingElement
        style={{
          top: '10%',
          left: '10%',
          width: '100px',
          height: '100px',
        }}
        animate={{
          y: [0, -20, 0],
          x: [0, 10, 0],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <FloatingElement
        style={{
          top: '20%',
          right: '15%',
          width: '60px',
          height: '60px',
        }}
        animate={{
          y: [0, 15, 0],
          x: [0, -15, 0],
          rotate: [0, -180, -360],
        }}
        transition={{
          duration: 12,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <FloatingElement
        style={{
          bottom: '15%',
          left: '20%',
          width: '80px',
          height: '80px',
        }}
        animate={{
          y: [0, -25, 0],
          x: [0, 20, 0],
          rotate: [0, 90, 180],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ 
          duration: 0.6,
          ease: "easeOut",
        }}
      >
        <LoginCard>
          <LogoContainer>
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ 
                duration: 0.8,
                delay: 0.2,
                ease: "easeOut",
              }}
            >
              <Logo>
                SiCE
              </Logo>
            </motion.div>
            <ResponsiveTitle level={2}>
              Bienvenido
            </ResponsiveTitle>
            <ResponsiveText type="secondary">
              Ingresa tus credenciales para continuar
            </ResponsiveText>
          </LogoContainer>

          <StyledForm
            form={form}
            name="login"
            onFinish={handleFormFinish}
            autoComplete="off"
          >
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Form.Item
                name="username"
                rules={[
                  { required: true, message: 'Por favor ingresa tu usuario' },
                  { min: 3, message: 'El usuario debe tener al menos 3 caracteres' },
                ]}
              >
                <Input
                  prefix={<UserOutlined style={{ color: '#52c41a' }} />}
                  placeholder="Usuario"
                  size="large"
                />
              </Form.Item>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Form.Item
                name="password"
                rules={[
                  { required: true, message: 'Por favor ingresa tu contraseña' },
                  { min: 4, message: 'La contraseña debe tener al menos 4 caracteres' },
                ]}
              >
                <Input.Password
                  prefix={<LockOutlined style={{ color: '#52c41a' }} />}
                  placeholder="Contraseña"
                  size="large"
                  iconRender={(visible) => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />)}
                />
              </Form.Item>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <Form.Item>
                <LoginButton
                  type="primary"
                  htmlType="submit"
                  loading={loading}
                  icon={<LoginOutlined />}
                >
                  {loading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
                </LoginButton>
              </Form.Item>
            </motion.div>
          </StyledForm>

          <ResponsiveDivider>
            <ResponsiveText type="secondary">Sistema de Compras Emergentes</ResponsiveText>
          </ResponsiveDivider>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <Space direction="vertical" style={{ width: '100%', textAlign: 'center' }}>
              <ResponsiveText type="secondary" style={{ fontSize: '11px' }}>
                © 2025 SiCE. Todos los derechos reservados.
              </ResponsiveText>
              <ResponsiveText type="secondary" style={{ fontSize: '11px' }}>
                Versión 1.0.0
              </ResponsiveText>
            </Space>
          </motion.div>
        </LoginCard>
      </motion.div>
    </LoginContainer>
  );
};

export default Login;
