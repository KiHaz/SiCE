import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Card, 
  Button, 
  Typography, 
  Space, 
  Avatar, 
  Tag,
  Descriptions,
  Badge,
  Row,
  Col,
  List
} from 'antd';
import { 
  UserOutlined, 
  ArrowLeftOutlined, 
  EditOutlined,
  MailOutlined,
  CalendarOutlined,
  ClockCircleOutlined,
  CheckCircleOutlined
} from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import type { User, UserRole } from '../../types';
import { userStorage } from '../../services/userStorage';

const { Title, Paragraph } = Typography;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
`;

const HeaderCard = styled(StyledCard)`
  margin-bottom: 24px;
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  border: 1px solid rgba(82, 196, 26, 0.2);
`;

const ProfileCard = styled(StyledCard)`
  text-align: center;
  padding: 40px 24px;
`;

const DetailsCard = styled(StyledCard)`
  margin-top: 24px;
  
  .ant-descriptions-item-label {
    font-weight: 500;
    color: #262626;
  }
`;

const ViewProfile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    if (id) {
      const foundUser = userStorage.getUserById(id);
      if (foundUser) {
        setUser(foundUser);
      }
    }
  }, [id]);

  const getRoleColor = (role: UserRole) => {
    const colors: { [key: number]: string } = {
      1: '#52c41a', // Admin
      2: '#1890ff', // Manager
      3: '#faad14', // User
      4: '#8c8c8c'  // Guest
    };
    return colors[role.level] || '#8c8c8c';
  };

  const handleEdit = () => {
    if (user) {
      navigate(`/profiles/edit/${user.id}`);
    }
  };

  if (!user) {
    return (
      <div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <HeaderCard>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <Title level={2} style={{ margin: 0, color: '#ff4d4f' }}>
                  Usuario no encontrado
                </Title>
                <Paragraph style={{ margin: '8px 0 0', color: '#666' }}>
                  El usuario que intentas ver no existe en el sistema
                </Paragraph>
              </div>
              <Button 
                icon={<ArrowLeftOutlined />}
                onClick={() => navigate('/profiles')}
                size="large"
              >
                Volver
              </Button>
            </div>
          </HeaderCard>
        </motion.div>
      </div>
    );
  }

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <HeaderCard>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <Title level={2} style={{ margin: 0, color: '#52c41a' }}>
                Detalles del Usuario
              </Title>
              <Paragraph style={{ margin: '8px 0 0 0', color: '#595959' }}>
                Información completa del perfil
              </Paragraph>
            </div>
            <Space>
              <Button 
                icon={<EditOutlined />}
                onClick={handleEdit}
                size="large"
                type="primary"
                style={{
                  background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                  border: 'none',
                  borderRadius: '8px'
                }}
              >
                Editar
              </Button>
              <Button 
                icon={<ArrowLeftOutlined />}
                onClick={() => navigate('/profiles')}
                size="large"
              >
                Volver
              </Button>
            </Space>
          </div>
        </HeaderCard>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <Row gutter={24}>
          <Col xs={24} md={8}>
            <ProfileCard>
              <Avatar
                size={120}
                icon={<UserOutlined />}
                src={user.avatar}
                style={{ 
                  background: getRoleColor(user.role),
                  border: '4px solid white',
                  boxShadow: '0 8px 24px rgba(0, 0, 0, 0.1)',
                  marginBottom: '16px'
                }}
              />
              <Title level={3} style={{ margin: '16px 0 8px', color: '#262626' }}>
                {user.firstName} {user.lastName}
              </Title>
              <Paragraph style={{ color: '#8c8c8c', fontSize: '16px' }}>
                @{user.username}
              </Paragraph>
              <Tag 
                color={getRoleColor(user.role)}
                style={{ 
                  fontSize: '14px',
                  padding: '4px 12px',
                  marginBottom: '16px'
                }}
              >
                {user.role.displayName}
              </Tag>
              <div>
                <Badge 
                  status={user.isActive ? 'success' : 'error'}
                  text={user.isActive ? 'Activo' : 'Inactivo'}
                  style={{ fontSize: '14px' }}
                />
              </div>
            </ProfileCard>
          </Col>

          <Col xs={24} md={16}>
            <DetailsCard>
              <Title level={4} style={{ color: '#52c41a', marginBottom: '24px' }}>
                Información Personal
              </Title>
              <Descriptions column={1} bordered>
                <Descriptions.Item 
                  label={<><MailOutlined style={{ marginRight: '8px' }} />Email</>}
                >
                  {user.email}
                </Descriptions.Item>
                <Descriptions.Item 
                  label={<><UserOutlined style={{ marginRight: '8px' }} />Usuario</>}
                >
                  {user.username}
                </Descriptions.Item>
                <Descriptions.Item 
                  label={<><CalendarOutlined style={{ marginRight: '8px' }} />Fecha de Creación</>}
                >
                  {new Date(user.createdAt).toLocaleDateString('es-ES', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </Descriptions.Item>
                <Descriptions.Item 
                  label={<><ClockCircleOutlined style={{ marginRight: '8px' }} />Último Acceso</>}
                >
                  {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString('es-ES', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  }) : 'Nunca'}
                </Descriptions.Item>
              </Descriptions>
            </DetailsCard>

            <DetailsCard>
              <Title level={4} style={{ color: '#52c41a', marginBottom: '24px' }}>
                Permisos del Usuario
              </Title>
              <List
                grid={{ 
                  gutter: 16, 
                  xs: 1, 
                  sm: 2, 
                  md: 2, 
                  lg: 3, 
                  xl: 3, 
                  xxl: 4 
                }}
                dataSource={user.permissions || []}
                renderItem={(permission: any) => (
                  <List.Item>
                    <Card
                      size="small"
                      style={{
                        border: '1px solid rgba(82, 196, 26, 0.1)',
                        borderRadius: '8px',
                        background: 'rgba(82, 196, 26, 0.05)'
                      }}
                    >
                      <Space>
                        <CheckCircleOutlined style={{ color: '#52c41a' }} />
                        <span style={{ fontSize: '12px' }}>
                          {permission.displayName || permission.name}
                        </span>
                      </Space>
                    </Card>
                  </List.Item>
                )}
              />
              {(!user.permissions || user.permissions.length === 0) && (
                <Typography.Text type="secondary">
                  Este usuario no tiene permisos específicos asignados.
                </Typography.Text>
              )}
            </DetailsCard>
          </Col>
        </Row>
      </motion.div>
    </div>
  );
};

export default ViewProfile;
