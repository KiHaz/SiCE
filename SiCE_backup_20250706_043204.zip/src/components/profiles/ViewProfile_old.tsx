import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Card, 
  Button, 
  Typography, 
  Space, 
  Avatar, 
  Tag,
  Descriptions,
  Badge,
  Divider,
  Row,
  Col,
  List
} from 'antd';
import { 
  UserOutlined, 
  ArrowLeftOutlined, 
  EditOutlined,
  MailOutlined,
  CalendarOutlined,
  ClockCircleOutlined,
  CheckCircleOutlined
} from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import type { User, UserRole } from '../../types';
import { userStorage } from '../../services/userStorage';

const { Title, Paragraph } = Typography;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
`;

const HeaderCard = styled(StyledCard)`
  margin-bottom: 24px;
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  border: 1px solid rgba(82, 196, 26, 0.2);
`;

const ProfileCard = styled(StyledCard)`
  text-align: center;
  
  .profile-avatar {
    margin-bottom: 16px;
  }
`;

const DetailsCard = styled(StyledCard)`
  .ant-descriptions-item-label {
    font-weight: 500;
    color: #262626;
  }
`;

const ViewProfile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    if (id) {
      const foundUser = userStorage.getUserById(id);
      if (foundUser) {
        setUser(foundUser);
      }
    }
  }, [id]);

  const getRoleColor = (role: UserRole) => {
    const colors: { [key: number]: string } = {
      1: '#52c41a', // Admin
      2: '#1890ff', // Manager
      3: '#faad14', // User
      4: '#8c8c8c'  // Guest
    };
    return colors[role.level] || '#8c8c8c';
  };

  const handleEdit = () => {
    if (user) {
      navigate(`/profiles/edit/${user.id}`);
    }
  };

  if (!user) {
    return (
      <div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <HeaderCard>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <Title level={2} style={{ margin: 0, color: '#ff4d4f' }}>
                  Usuario no encontrado
                </Title>
                <Paragraph style={{ margin: '8px 0 0', color: '#666' }}>
                  El usuario que intentas ver no existe en el sistema
                </Paragraph>
              </div>
              <Button 
                icon={<ArrowLeftOutlined />}
                onClick={() => navigate('/profiles')}
                size="large"
              >
                Volver
              </Button>
            </div>
          </HeaderCard>
        </motion.div>
      </div>
    );
  }
    navigate(`/profiles/edit/${id}`);
  };

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <HeaderCard>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <Title level={2} style={{ margin: 0, color: '#52c41a' }}>
                Perfil de Usuario
              </Title>
              <Paragraph style={{ margin: '8px 0 0 0', color: '#595959' }}>
                Información detallada del usuario
              </Paragraph>
            </div>
            <Space>
              <Button 
                icon={<ArrowLeftOutlined />}
                onClick={() => navigate('/profiles')}
                size="large"
              >
                Volver
              </Button>
              <Button 
                type="primary"
                icon={<EditOutlined />}
                onClick={handleEdit}
                size="large"
                style={{
                  background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                  border: 'none'
                }}
              >
                Editar
              </Button>
            </Space>
          </div>
        </HeaderCard>
      </motion.div>

      <Row gutter={[24, 24]}>
        <Col xs={24} md={8}>
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <ProfileCard>
              <div className="profile-avatar">
                <Avatar
                  size={120}
                  icon={<UserOutlined />}
                  src={user.avatar}
                  style={{ 
                    background: getRoleColor(user.role),
                    border: `4px solid ${getRoleColor(user.role)}20`,
                    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </div>
              <Title level={3} style={{ margin: '0 0 8px 0', color: '#262626' }}>
                {user.firstName} {user.lastName}
              </Title>
              <Paragraph style={{ margin: '0 0 16px 0', color: '#8c8c8c' }}>
                @{user.username}
              </Paragraph>
              <Tag 
                color={getRoleColor(user.role)}
                style={{ 
                  fontSize: '14px',
                  padding: '4px 12px',
                  borderRadius: '16px',
                  marginBottom: '16px'
                }}
              >
                {user.role.displayName}
              </Tag>
              <div>
                <Badge 
                  status={user.isActive ? 'success' : 'error'}
                  text={user.isActive ? 'Usuario Activo' : 'Usuario Inactivo'}
                  style={{ fontSize: '14px' }}
                />
              </div>
            </ProfileCard>
          </motion.div>
        </Col>

        <Col xs={24} md={16}>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <DetailsCard title="Información Personal">
              <Descriptions 
                column={{ xs: 1, sm: 1, md: 2 }}
                bordered
                size="middle"
              >
                <Descriptions.Item 
                  label={<><UserOutlined /> Nombre Completo</>}
                >
                  {user.firstName} {user.lastName}
                </Descriptions.Item>
                <Descriptions.Item 
                  label={<><UserOutlined /> Usuario</>}
                >
                  @{user.username}
                </Descriptions.Item>
                <Descriptions.Item 
                  label={<><MailOutlined /> Email</>}
                >
                  {user.email}
                </Descriptions.Item>
                <Descriptions.Item 
                  label="Rol"
                >
                  <Tag color={getRoleColor(user.role)}>
                    {user.role.displayName}
                  </Tag>
                </Descriptions.Item>
                <Descriptions.Item 
                  label={<><CalendarOutlined /> Fecha de Creación</>}
                >
                  {user.createdAt.toLocaleDateString()}
                </Descriptions.Item>
                <Descriptions.Item 
                  label={<><ClockCircleOutlined /> Último Acceso</>}
                >
                  {user.lastLogin ? user.lastLogin.toLocaleDateString() : 'Nunca'}
                </Descriptions.Item>
              </Descriptions>
            </DetailsCard>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <DetailsCard 
              title="Descripción del Rol"
              style={{ marginTop: '24px' }}
            >
              <Paragraph style={{ margin: 0, color: '#595959' }}>
                {user.role.description}
              </Paragraph>
              <Divider style={{ margin: '16px 0' }} />
              <div>
                <Title level={5} style={{ margin: '0 0 12px 0', color: '#52c41a' }}>
                  Nivel de Acceso
                </Title>
                <Tag color={getRoleColor(user.role)} style={{ fontSize: '12px' }}>
                  Nivel {user.role.level}
                </Tag>
              </div>
            </DetailsCard>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
          >
            <DetailsCard 
              title="Permisos del Usuario"
              style={{ marginTop: '24px' }}
            >
              {user.permissions.length > 0 ? (
                <Space wrap>
                  {user.permissions.map((permission) => (
                    <Tag key={permission.id} color="blue">
                      {permission.displayName}
                    </Tag>
                  ))}
                </Space>
              ) : (
                <Paragraph style={{ margin: 0, color: '#8c8c8c' }}>
                  Los permisos se asignan automáticamente según el rol del usuario.
                </Paragraph>
              )}
            </DetailsCard>
          </motion.div>
        </Col>
      </Row>
    </div>
  );
};

export default ViewProfile;
