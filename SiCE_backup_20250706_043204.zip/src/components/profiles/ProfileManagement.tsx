import React, { useState, useEffect } from 'react';
import { 
  Card, 
  Button, 
  Table, 
  Space, 
  Tag, 
  Avatar, 
  Typography, 
  Input, 
  Select, 
  Dropdown,
  Modal,
  Tooltip,
  Badge,
  Statistic,
  Row,
  Col
} from 'antd';
import { 
  UserOutlined, 
  PlusOutlined, 
  EditOutlined, 
  DeleteOutlined, 
  EyeOutlined,
  SearchOutlined,
  FilterOutlined,
  MoreOutlined,
  ReloadOutlined,
  ClearOutlined
} from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import type { User, UserRole } from '../../types';
import { useUsers } from '../../hooks/useUsers';
import { useUserFilters } from '../../hooks/useUserFilters';
import { useUserStorageEvents, USER_STORAGE_EVENTS } from '../../utils/events';

const { Title, Paragraph } = Typography;
const { Search } = Input;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
`;

const HeaderCard = styled(StyledCard)`
  margin-bottom: 24px;
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  border: 1px solid rgba(82, 196, 26, 0.2);
`;

const TableCard = styled(StyledCard)`
  .ant-table-wrapper {
    background: transparent;
  }
  
  .ant-table {
    background: transparent;
  }
  
  .ant-table-thead > tr > th {
    background: rgba(82, 196, 26, 0.05);
    border-bottom: 1px solid rgba(82, 196, 26, 0.1);
  }
  
  .ant-table-tbody > tr:hover > td {
    background: rgba(82, 196, 26, 0.05);
  }
`;

const ActionButton = styled(Button)`
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
`;

const StatsCard = styled(StyledCard)`
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.05), rgba(115, 209, 61, 0.05));
  border: 1px solid rgba(82, 196, 26, 0.1);
  margin-bottom: 16px;
  
  .ant-statistic-title {
    color: #595959;
    font-size: 14px;
  }
  
  .ant-statistic-content {
    color: #52c41a;
    font-weight: 600;
  }
`;

const FilterRow = styled.div`
  display: flex;
  gap: 16px;
  align-items: center;
  margin-bottom: 16px;
  flex-wrap: wrap;
`;

const ProfileManagement: React.FC = () => {
  const navigate = useNavigate();
  const { users, loading, deleteUser, refreshUsers } = useUsers();
  const { 
    searchText, 
    setSearchText, 
    selectedRole, 
    setSelectedRole,
    statusFilter,
    setStatusFilter,
    filteredUsers, 
    stats,
    resetFilters
  } = useUserFilters(users);
  
  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  // Escuchar cambios en el storage para recarga automática
  useEffect(() => {
    const handleStorageChange = () => {
      refreshUsers();
    };

    // Agregar listener para cambios en localStorage
    window.addEventListener('storage', handleStorageChange);
    
    // Intervalo para verificar cambios periódicamente
    const interval = setInterval(() => {
      refreshUsers();
    }, 30000); // Cada 30 segundos

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [refreshUsers]);

  // Escuchar eventos del sistema de usuarios
  useUserStorageEvents((eventType) => {
    if (eventType === USER_STORAGE_EVENTS.USER_UPDATED || 
        eventType === USER_STORAGE_EVENTS.USER_DELETED || 
        eventType === USER_STORAGE_EVENTS.USER_CREATED) {
      refreshUsers();
    }
  });

  const handleCreateUser = () => {
    navigate('/profiles/create');
  };

  const handleEditUser = (user: User) => {
    navigate(`/profiles/edit/${user.id}`);
  };

  const handleViewUser = (user: User) => {
    navigate(`/profiles/view/${user.id}`);
  };

  const handleDeleteUser = (user: User) => {
    setUserToDelete(user);
    setDeleteModalVisible(true);
  };

  const confirmDelete = async () => {
    if (userToDelete) {
      const success = await deleteUser(userToDelete.id);
      if (success) {
        setDeleteModalVisible(false);
        setUserToDelete(null);
      }
    }
  };

  const getRoleColor = (role: UserRole) => {
    const colors: { [key: number]: string } = {
      1: '#52c41a', // Admin
      2: '#1890ff', // Manager
      3: '#faad14', // User
      4: '#8c8c8c'  // Guest
    };
    return colors[role.level] || '#8c8c8c';
  };

  const columns = [
    {
      title: 'Usuario',
      dataIndex: 'user',
      key: 'user',
      render: (_: string, record: User) => (
        <Space>
          <Avatar
            size="large"
            icon={<UserOutlined />}
            src={record.avatar}
            style={{ 
              background: getRoleColor(record.role),
              border: `2px solid ${getRoleColor(record.role)}20`
            }}
          />
          <div>
            <div style={{ fontWeight: 500 }}>
              {record.firstName} {record.lastName}
            </div>
            <div style={{ color: '#8c8c8c', fontSize: '12px' }}>
              @{record.username}
            </div>
          </div>
        </Space>
      )
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
      render: (email: string) => (
        <span style={{ color: '#595959' }}>{email}</span>
      )
    },
    {
      title: 'Rol',
      dataIndex: 'role',
      key: 'role',
      render: (role: UserRole) => (
        <Tag color={getRoleColor(role)}>
          {role.displayName}
        </Tag>
      )
    },
    {
      title: 'Estado',
      dataIndex: 'isActive',
      key: 'isActive',
      render: (isActive: boolean) => (
        <Badge 
          status={isActive ? 'success' : 'error'}
          text={isActive ? 'Activo' : 'Inactivo'}
        />
      )
    },
    {
      title: 'Último acceso',
      dataIndex: 'lastLogin',
      key: 'lastLogin',
      render: (lastLogin: Date) => (
        <span style={{ color: '#8c8c8c' }}>
          {lastLogin ? new Date(lastLogin).toLocaleDateString() : 'Nunca'}
        </span>
      )
    },
    {
      title: 'Acciones',
      key: 'actions',
      render: (_: string, record: User) => {
        const items = [
          {
            key: 'view',
            icon: <EyeOutlined />,
            label: 'Ver detalles',
            onClick: () => handleViewUser(record)
          },
          {
            key: 'edit',
            icon: <EditOutlined />,
            label: 'Editar',
            onClick: () => handleEditUser(record)
          },
          {
            type: 'divider' as const
          },
          {
            key: 'delete',
            icon: <DeleteOutlined />,
            label: 'Eliminar',
            danger: true,
            onClick: () => handleDeleteUser(record),
            disabled: record.username === 'admin' // No permitir eliminar admin
          }
        ];

        return (
          <Space>
            <Tooltip title="Ver detalles">
              <ActionButton 
                type="text" 
                icon={<EyeOutlined />}
                onClick={() => handleViewUser(record)}
              />
            </Tooltip>
            <Tooltip title="Editar">
              <ActionButton 
                type="text" 
                icon={<EditOutlined />}
                onClick={() => handleEditUser(record)}
              />
            </Tooltip>
            <Dropdown menu={{ items }} trigger={['click']}>
              <ActionButton type="text" icon={<MoreOutlined />} />
            </Dropdown>
          </Space>
        );
      }
    }
  ];

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <HeaderCard>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <Title level={2} style={{ margin: 0, color: '#52c41a' }}>
                Gestión de Perfiles
              </Title>
              <Paragraph style={{ margin: '8px 0 0 0', color: '#595959' }}>
                Administra los usuarios y sus permisos en el sistema
              </Paragraph>
            </div>
            <Button 
              type="primary" 
              icon={<PlusOutlined />}
              size="large"
              onClick={handleCreateUser}
              style={{
                background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                border: 'none',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(82, 196, 26, 0.3)'
              }}
            >
              Crear Perfil
            </Button>
          </div>
        </HeaderCard>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <TableCard>
          {/* Estadísticas */}
          <StatsCard>
            <Row gutter={16}>
              <Col span={6}>
                <Statistic title="Total de Usuarios" value={stats.total} />
              </Col>
              <Col span={6}>
                <Statistic title="Activos" value={stats.active} valueStyle={{ color: '#52c41a' }} />
              </Col>
              <Col span={6}>
                <Statistic title="Inactivos" value={stats.inactive} valueStyle={{ color: '#ff4d4f' }} />
              </Col>
              <Col span={6}>
                <Statistic title="Administradores" value={stats.byRole.administrator || 0} />
              </Col>
            </Row>
          </StatsCard>

          {/* Filtros */}
          <FilterRow>
            <Search
              placeholder="Buscar por nombre, email o usuario..."
              allowClear
              enterButton={<SearchOutlined />}
              size="large"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              style={{ flex: 1, maxWidth: '400px' }}
            />
            <Select
              placeholder="Filtrar por rol"
              size="large"
              value={selectedRole}
              onChange={setSelectedRole}
              style={{ minWidth: '150px' }}
              suffixIcon={<FilterOutlined />}
            >
              <Select.Option value="all">Todos los roles</Select.Option>
              <Select.Option value="administrator">Administrador</Select.Option>
              <Select.Option value="manager">Gerente</Select.Option>
              <Select.Option value="user">Usuario</Select.Option>
              <Select.Option value="guest">Invitado</Select.Option>
            </Select>
            <Select
              placeholder="Estado"
              size="large"
              value={statusFilter}
              onChange={setStatusFilter}
              style={{ minWidth: '120px' }}
            >
              <Select.Option value="all">Todos</Select.Option>
              <Select.Option value="active">Activos</Select.Option>
              <Select.Option value="inactive">Inactivos</Select.Option>
            </Select>
            <Tooltip title="Recargar usuarios">
              <Button
                icon={<ReloadOutlined />}
                size="large"
                onClick={refreshUsers}
              />
            </Tooltip>
            <Tooltip title="Limpiar filtros">
              <Button
                icon={<ClearOutlined />}
                size="large"
                onClick={resetFilters}
              />
            </Tooltip>
          </FilterRow>
          
          <Table
            columns={columns}
            dataSource={filteredUsers}
            loading={loading}
            rowKey="id"
            pagination={{
              showSizeChanger: true,
              showQuickJumper: true,
              showTotal: (total, range) => 
                `${range[0]}-${range[1]} de ${total} usuarios`,
              pageSizeOptions: ['10', '20', '50', '100']
            }}
            scroll={{ x: 800 }}
          />
        </TableCard>
      </motion.div>

      <Modal
        title="Confirmar eliminación"
        open={deleteModalVisible}
        onOk={confirmDelete}
        onCancel={() => setDeleteModalVisible(false)}
        okText="Eliminar"
        cancelText="Cancelar"
        okButtonProps={{ danger: true }}
      >
        <p>
          ¿Está seguro que desea eliminar el usuario{' '}
          <strong>
            {userToDelete?.firstName} {userToDelete?.lastName}
          </strong>
          ?
        </p>
        <p style={{ color: '#ff4d4f' }}>
          Esta acción no se puede deshacer.
        </p>
      </Modal>
    </div>
  );
};

export default ProfileManagement;
