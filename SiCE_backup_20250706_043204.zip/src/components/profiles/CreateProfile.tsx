import React, { useState } from 'react';
import { 
  Card, 
  Form, 
  Input, 
  Button, 
  Select, 
  Typography, 
  Space, 
  message,
  Row,
  Col,
  Avatar,
  Upload,
  Divider
} from 'antd';
import { 
  UserOutlined, 
  SaveOutlined, 
  ArrowLeftOutlined,
  UploadOutlined,
  EyeInvisibleOutlined,
  EyeTwoTone
} from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import type { CreateUserForm } from '../../types';
import { userStorage, systemRoles, systemPermissions } from '../../services/userStorage';

const { Title, Paragraph } = Typography;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
`;

const HeaderCard = styled(StyledCard)`
  margin-bottom: 24px;
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  border: 1px solid rgba(82, 196, 26, 0.2);
`;

const FormCard = styled(StyledCard)`
  .ant-form-item-label > label {
    font-weight: 500;
    color: #262626;
  }
`;

const AvatarUpload = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  padding: 24px;
  border: 2px dashed rgba(82, 196, 26, 0.3);
  border-radius: 8px;
  background: rgba(82, 196, 26, 0.05);
  transition: all 0.3s ease;
  
  &:hover {
    border-color: rgba(82, 196, 26, 0.5);
    background: rgba(82, 196, 26, 0.1);
  }
`;

const CreateProfile: React.FC = () => {
  const navigate = useNavigate();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [avatar, setAvatar] = useState<string | null>(null);

  const handleSubmit = async (values: CreateUserForm) => {
    setLoading(true);
    
    try {
      // Crear usuario usando el sistema de almacenamiento
      const newUser = userStorage.createUser(values);
      
      message.success(`Perfil creado exitosamente para ${newUser.firstName} ${newUser.lastName}`);
      navigate('/profiles');
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Error al crear el perfil';
      message.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleAvatarChange = (info: any) => {
    if (info.file.status === 'done') {
      setAvatar(info.file.response.url);
    }
  };

  const beforeUpload = (file: File) => {
    const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
    if (!isJpgOrPng) {
      message.error('Solo se permiten archivos JPG/PNG');
      return false;
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('La imagen debe ser menor a 2MB');
      return false;
    }
    return true;
  };

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <HeaderCard>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <Title level={2} style={{ margin: 0, color: '#52c41a' }}>
                Crear Nuevo Perfil
              </Title>
              <Paragraph style={{ margin: '8px 0 0 0', color: '#595959' }}>
                Ingresa la información del nuevo usuario
              </Paragraph>
            </div>
            <Button 
              icon={<ArrowLeftOutlined />}
              onClick={() => navigate('/profiles')}
              size="large"
            >
              Volver
            </Button>
          </div>
        </HeaderCard>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <FormCard>
          <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            requiredMark="optional"
            scrollToFirstError
          >
            <Row gutter={24}>
              <Col xs={24} md={8}>
                <Form.Item label="Foto de Perfil">
                  <AvatarUpload>
                    <Avatar
                      size={80}
                      icon={<UserOutlined />}
                      src={avatar}
                      style={{ 
                        background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                        border: '3px solid white',
                        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)'
                      }}
                    />
                    <Upload
                      name="avatar"
                      showUploadList={false}
                      action="/api/upload"
                      beforeUpload={beforeUpload}
                      onChange={handleAvatarChange}
                    >
                      <Button icon={<UploadOutlined />}>
                        Subir Imagen
                      </Button>
                    </Upload>
                  </AvatarUpload>
                </Form.Item>
              </Col>
              
              <Col xs={24} md={16}>
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item
                      label="Nombre"
                      name="firstName"
                      rules={[
                        { required: true, message: 'El nombre es requerido' },
                        { min: 2, message: 'El nombre debe tener al menos 2 caracteres' }
                      ]}
                    >
                      <Input 
                        placeholder="Ingresa el nombre"
                        size="large"
                      />
                    </Form.Item>
                  </Col>
                  
                  <Col xs={24} md={12}>
                    <Form.Item
                      label="Apellido"
                      name="lastName"
                      rules={[
                        { required: true, message: 'El apellido es requerido' },
                        { min: 2, message: 'El apellido debe tener al menos 2 caracteres' }
                      ]}
                    >
                      <Input 
                        placeholder="Ingresa el apellido"
                        size="large"
                      />
                    </Form.Item>
                  </Col>
                </Row>
                
                <Row gutter={16}>
                  <Col xs={24} md={12}>
                    <Form.Item
                      label="Usuario"
                      name="username"
                      rules={[
                        { required: true, message: 'El usuario es requerido' },
                        { min: 3, message: 'El usuario debe tener al menos 3 caracteres' },
                        { pattern: /^[a-zA-Z0-9_]+$/, message: 'Solo letras, números y guiones bajos' }
                      ]}
                    >
                      <Input 
                        placeholder="Ingresa el usuario"
                        size="large"
                        prefix={<UserOutlined />}
                      />
                    </Form.Item>
                  </Col>
                  
                  <Col xs={24} md={12}>
                    <Form.Item
                      label="Email"
                      name="email"
                      rules={[
                        { required: true, message: 'El email es requerido' },
                        { type: 'email', message: 'Ingresa un email válido' }
                      ]}
                    >
                      <Input 
                        placeholder="Ingresa el email"
                        size="large"
                        type="email"
                      />
                    </Form.Item>
                  </Col>
                </Row>
              </Col>
            </Row>

            <Divider style={{ margin: '32px 0' }} />

            <Row gutter={24}>
              <Col xs={24} md={12}>
                <Form.Item
                  label="Contraseña"
                  name="password"
                  rules={[
                    { required: true, message: 'La contraseña es requerida' },
                    { min: 6, message: 'La contraseña debe tener al menos 6 caracteres' }
                  ]}
                >
                  <Input.Password 
                    placeholder="Ingresa la contraseña"
                    size="large"
                    iconRender={(visible) => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />)}
                  />
                </Form.Item>
              </Col>
              
              <Col xs={24} md={12}>
                <Form.Item
                  label="Confirmar Contraseña"
                  name="confirmPassword"
                  dependencies={['password']}
                  rules={[
                    { required: true, message: 'Confirma la contraseña' },
                    ({ getFieldValue }) => ({
                      validator(_, value) {
                        if (!value || getFieldValue('password') === value) {
                          return Promise.resolve();
                        }
                        return Promise.reject(new Error('Las contraseñas no coinciden'));
                      },
                    }),
                  ]}
                >
                  <Input.Password 
                    placeholder="Confirma la contraseña"
                    size="large"
                    iconRender={(visible) => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />)}
                  />
                </Form.Item>
              </Col>
            </Row>

            <Divider style={{ margin: '32px 0' }} />

            <Row gutter={24}>
              <Col xs={24} md={12}>
                <Form.Item
                  label="Rol"
                  name="roleId"
                  rules={[{ required: true, message: 'Selecciona un rol' }]}
                >
                  <Select 
                    placeholder="Selecciona un rol"
                    size="large"
                  >
                    {systemRoles.filter(role => role.name !== 'administrator').map(role => (
                      <Select.Option key={role.id} value={role.id}>
                        <Space>
                          <div 
                            style={{
                              width: '8px',
                              height: '8px',
                              borderRadius: '50%',
                              background: role.color
                            }}
                          />
                          {role.displayName}
                        </Space>
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>
              
              <Col xs={24} md={12}>
                <Form.Item
                  label="Permisos"
                  name="permissions"
                >
                  <Select 
                    mode="multiple"
                    placeholder="Selecciona permisos"
                    size="large"
                    allowClear
                  >
                    {systemPermissions.filter(permission => permission.name !== 'users' && permission.name !== 'settings').map(permission => (
                      <Select.Option key={permission.id} value={permission.id}>
                        {permission.displayName}
                      </Select.Option>
                    ))}
                  </Select>
                </Form.Item>
              </Col>
            </Row>

            <Divider style={{ margin: '32px 0' }} />

            <div style={{ textAlign: 'center' }}>
              <Space size="large">
                <Button 
                  size="large"
                  onClick={() => navigate('/profiles')}
                >
                  Cancelar
                </Button>
                <Button 
                  type="primary"
                  size="large"
                  htmlType="submit"
                  loading={loading}
                  icon={<SaveOutlined />}
                  style={{
                    background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                    border: 'none',
                    minWidth: '150px'
                  }}
                >
                  Crear Perfil
                </Button>
              </Space>
            </div>
          </Form>
        </FormCard>
      </motion.div>
    </div>
  );
};

export default CreateProfile;
