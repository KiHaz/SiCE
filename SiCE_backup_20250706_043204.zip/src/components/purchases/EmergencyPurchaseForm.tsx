import React, { useState, useCallback } from 'react';
import {
  Card,
  Form,
  Input,
  Button,
  Row,
  Col,
  Typography,
  InputNumber,
  message
} from 'antd';
import { PlusOutlined, DeleteOutlined, PrinterOutlined, ExpandAltOutlined } from '@ant-design/icons';
import styled from '@emotion/styled';

const { Title, Paragraph } = Typography;
const { TextArea } = Input;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
`;

const HeaderCard = styled(StyledCard)`
  margin-bottom: 6px;
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  border: 1px solid rgba(82, 196, 26, 0.2);
  padding: 12px;
`;

const SectionCard = styled(StyledCard)`
  margin-bottom: 6px;
  padding: 8px;
  
  .ant-form-item-label > label {
    font-weight: 500;
    color: #262626;
    font-size: 11px;
    margin-bottom: 2px;
  }
  
  .ant-form-item {
    margin-bottom: 6px;
  }
`;

const InlineSection = styled.div`
  display: flex;
  gap: 12px;
  align-items: flex-start;
  margin-bottom: 6px;
  
  .inline-group {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
`;

const KeyDataCard = styled.div`
  display: flex;
  gap: 6px;
  margin-bottom: 8px;
  
  .key-item {
    padding: 3px 6px;
    background: rgba(82, 196, 26, 0.1);
    border: 1px solid rgba(82, 196, 26, 0.2);
    border-radius: 3px;
    font-weight: 500;
    color: #52c41a;
    font-size: 10px;
  }
`;

const FolioSection = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
  
  .folio-label {
    font-weight: 500;
    color: #262626;
    font-size: 11px;
  }
  
  .folio-value {
    background: rgba(82, 196, 26, 0.1);
    padding: 3px 6px;
    border: 1px solid rgba(82, 196, 26, 0.2);
    border-radius: 3px;
    color: #52c41a;
    font-weight: 500;
    font-size: 10px;
  }
`;

const SignatureSection = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 6px;
  
  .signature-item {
    text-align: center;
    
    .signature-title {
      font-weight: 500;
      color: #262626;
      margin-bottom: 2px;
      font-size: 9px;
    }
    
    .signature-field {
      border: 1px solid #d9d9d9;
      border-radius: 3px;
      padding: 4px;
      min-height: 30px;
      background: #fafafa;
      
      .name-field {
        border-bottom: 1px solid #d9d9d9;
        padding-bottom: 1px;
        margin-bottom: 1px;
        font-size: 7px;
        color: #8c8c8c;
      }
      
      .role-field {
        font-size: 7px;
        color: #8c8c8c;
      }
    }
  }
`;

const MainContainer = styled.div`
  display: flex;
  gap: 0;
  height: 100vh;
  max-height: 100vh;
  overflow: hidden;
`;

const FormContainer = styled.div`
  flex: 1;
  overflow: hidden;
  padding: 6px;
  height: 100vh;
  max-height: 100vh;
  display: flex;
  flex-direction: column;
`;


const SidePanel = styled.div`
  width: 300px;
  min-width: 240px;
  max-width: 340px;
  background: linear-gradient(135deg, #f6ffed 0%, #eaffd0 100%);
  border-left: 2px solid #b7eb8f;
  box-shadow: -2px 0 8px rgba(82, 196, 26, 0.08);
  display: flex;
  flex-direction: column;
  height: 100vh;
  max-height: 100vh;
  padding: 0;
`;

const PanelContent = styled.div`
  padding: 12px 8px 8px 8px;
  height: 100%;
  overflow: hidden;
  display: flex;
  flex-direction: column;
`;

const PanelHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
  padding-bottom: 6px;
  border-bottom: 1px solid #b7eb8f;
  flex-shrink: 0;
`;

const SummaryTable = styled.div`
  flex: 1;
  overflow-y: auto;
  margin-bottom: 8px;
  border-radius: 8px;
  background: rgba(82, 196, 26, 0.04);
  border: 1px solid #eaffd0;
  box-shadow: 0 2px 8px rgba(82, 196, 26, 0.04);
  padding: 8px 4px;

  .summary-header, .summary-row {
    display: flex;
    align-items: center;
    font-size: 12px;
    padding: 4px 0;
  }
  .summary-header {
    font-weight: bold;
    color: #52c41a;
    border-bottom: 1px solid #eaffd0;
    margin-bottom: 4px;
    background: none;
  }
  .summary-row {
    border-bottom: 1px dashed #eaffd0;
    &:last-child { border-bottom: none; }
    transition: background 0.2s;
    &:hover { background: #f6ffed; }
  }
  .col-num { width: 24px; text-align: center; color: #73d13d; }
  .col-clave { flex: 1; padding: 0 4px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .col-desc { flex: 2; padding: 0 4px; color: #595959; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .col-cant { width: 36px; text-align: right; color: #262626; }
  .col-total { width: 60px; text-align: right; color: #1890ff; font-weight: 500; }
  .col-action { width: 32px; text-align: center; }
`;

const PanelFooter = styled.div`
  padding: 8px 0 0 0;
  border-top: 1px solid #eaffd0;
  background: none;
  border-radius: 0 0 8px 8px;
  margin-top: 4px;
  text-align: center;
  flex-shrink: 0;
  font-size: 12px;
`;

interface RequirementItem {
  key: string;
  clave: string;
  description: string;
  presentation: string;
  quantity: number;
  type: string;
  unitPrice: number;
  totalPrice: number;
  justification: string;
}

const EmergencyPurchaseForm: React.FC = () => {
  const [form] = Form.useForm();
  const [requirements, setRequirements] = useState<RequirementItem[]>([]);
  const [counter, setCounter] = useState(1);
  const [expandedView, setExpandedView] = useState(false);

  const addRequirement = useCallback(() => {
    const newRequirement: RequirementItem = {
      key: `req-${counter}`,
      clave: '',
      description: '',
      presentation: '',
      quantity: 1,
      type: '',
      unitPrice: 0,
      totalPrice: 0,
      justification: ''
    };
    setRequirements(prev => [...prev, newRequirement]);
    setCounter(prev => prev + 1);
  }, [counter]);

  const removeRequirement = useCallback((key: string) => {
    setRequirements(prev => prev.filter(item => item.key !== key));
  }, []);


  const handleSubmit = useCallback((values: any) => {
    console.log('Formulario enviado:', { ...values, requirements });
    message.success('Solicitud de compra emergente guardada exitosamente');
  }, [requirements]);

  const handlePrint = useCallback(() => {
    window.print();
    message.info('Preparando impresión...');
  }, []);


  return (
    <MainContainer>
      <FormContainer>
        <HeaderCard>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <Title level={5} style={{ margin: 0, color: '#52c41a', fontSize: '16px' }}>
                SCE - Solicitud de Compras Emergentes
              </Title>
              <Paragraph style={{ margin: '1px 0 0 0', color: '#595959', fontSize: '11px' }}>
                Complete el formulario para generar una solicitud de compra emergente
              </Paragraph>
            </div>
            <Button
              type="primary"
              icon={<PrinterOutlined />}
              onClick={handlePrint}
              size="small"
              style={{
                background: 'linear-gradient(45deg, #52c41a, #73d13d)',
                border: 'none',
                borderRadius: '4px',
                height: '28px'
              }}
            >
              Imprimir
            </Button>
          </div>
        </HeaderCard>

        <Form
          form={form}
          layout="vertical"
          onFinish={handleSubmit}
          requiredMark={false}
          size="small"
        >
          {/* Fila 1: Clave, Folio y Descripción en una sola línea */}
          <InlineSection>
            <div className="inline-group" style={{ flex: '0 0 200px' }}>
              <SectionCard>
                <div style={{ fontSize: '12px', fontWeight: 500, color: '#262626', marginBottom: '4px' }}>
                  Datos de Clave
                </div>
                <KeyDataCard>
                  <span className="key-item">GPO</span>
                  <span className="key-item">GEN</span>
                  <span className="key-item">ESP</span>
                  <span className="key-item">DIF</span>
                  <span className="key-item">VAR</span>
                </KeyDataCard>
              </SectionCard>
            </div>
            
            <div className="inline-group" style={{ flex: '0 0 180px' }}>
              <SectionCard>
                <div style={{ fontSize: '12px', fontWeight: 500, color: '#262626', marginBottom: '4px' }}>
                  Folio
                </div>
                <FolioSection>
                  <span className="folio-label">Auto:</span>
                  <span className="folio-value">SiCE-ADMIN-2025-005</span>
                </FolioSection>
              </SectionCard>
            </div>
            
            <div className="inline-group">
              <SectionCard>
                <Form.Item
                  name="articleDescription"
                  label="Descripción del Artículo:"
                  rules={[{ required: true, message: 'Requerido' }]}
                >
                  <TextArea rows={1} placeholder="Descripción del artículo" />
                </Form.Item>
              </SectionCard>
            </div>
          </InlineSection>

          {/* Fila 2: Todos los campos de datos del artículo en una línea */}
          <SectionCard>
            <Row gutter={6}>
              <Col span={3}>
                <Form.Item name="unitPresentation" label="U. Pres:">
                  <Input placeholder="Unidad" size="small" />
                </Form.Item>
              </Col>
              <Col span={3}>
                <Form.Item name="containerPresentation" label="C. Pres:">
                  <Input placeholder="Cant." size="small" />
                </Form.Item>
              </Col>
              <Col span={3}>
                <Form.Item name="typePresentation" label="T. Pres:">
                  <Input placeholder="Tipo" size="small" />
                </Form.Item>
              </Col>
              <Col span={3}>
                <Form.Item name="cpmValue" label="CPM V:">
                  <InputNumber
                    style={{ width: '100%' }}
                    size="small"
                    placeholder="0.00"
                  />
                </Form.Item>
              </Col>
              <Col span={3}>
                <Form.Item name="sevenDaysReq" label="Rq. 7d:">
                  <InputNumber
                    style={{ width: '100%' }}
                    size="small"
                    placeholder="0.00"
                  />
                </Form.Item>
              </Col>
              <Col span={3}>
                <Form.Item name="requiredQuantity" label="C. Req:">
                  <InputNumber style={{ width: '100%' }} size="small" min={0} placeholder="0" />
                </Form.Item>
              </Col>
              <Col span={6}>
                <Form.Item name="justification" label="Justificación:">
                  <TextArea rows={1} placeholder="Justificación" />
                </Form.Item>
              </Col>
            </Row>
          </SectionCard>

          {/* Fila 3: Firmas más compactas */}
          <SectionCard>
            <div style={{ fontSize: '12px', fontWeight: 500, color: '#262626', marginBottom: '4px' }}>
              Firmas de Autorización
            </div>
            <SignatureSection>
              <div className="signature-item">
                <div className="signature-title">Para</div>
                <div className="signature-field">
                  <div className="name-field">Nombre</div>
                  <div className="role-field">Cargo</div>
                </div>
              </div>
              <div className="signature-item">
                <div className="signature-title">Solicitante</div>
                <div className="signature-field">
                  <div className="name-field">Nombre</div>
                  <div className="role-field">Cargo</div>
                </div>
              </div>
              <div className="signature-item">
                <div className="signature-title">Valida</div>
                <div className="signature-field">
                  <div className="name-field">Nombre</div>
                  <div className="role-field">Cargo</div>
                </div>
              </div>
              <div className="signature-item">
                <div className="signature-title">Autoriza</div>
                <div className="signature-field">
                  <div className="name-field">Nombre</div>
                  <div className="role-field">Cargo</div>
                </div>
              </div>
            </SignatureSection>
          </SectionCard>

          {/* Botón centrado */}
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: '6px' }}>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={addRequirement}
              style={{
                background: 'linear-gradient(45deg, #1890ff, #40a9ff)',
                border: 'none',
                borderRadius: '4px',
                padding: '0 16px',
                height: '28px',
                fontSize: '11px'
              }}
            >
              Agregar Requerimiento
            </Button>
          </div>

        </Form>
      </FormContainer>

      {/* Panel lateral derecho fijo */}
      <SidePanel>
        <PanelContent>
          <PanelHeader>
            <Typography.Title level={5} style={{ margin: 0, color: '#52c41a', fontSize: 15 }}>
              📋 Resumen ({requirements.length})
            </Typography.Title>
            <Button
              type="text"
              icon={<ExpandAltOutlined />}
              onClick={() => setExpandedView(!expandedView)}
              size="small"
              style={{ color: '#52c41a' }}
            >
              {expandedView ? 'Contraer' : 'Expandir'}
            </Button>
          </PanelHeader>

          <SummaryTable>
            <div className="summary-header">
              <div className="col-num">#</div>
              <div className="col-clave">Clave</div>
              <div className="col-desc">Descripción</div>
              <div className="col-cant">Cant</div>
              <div className="col-total">$Total</div>
              <div className="col-action"></div>
            </div>
            {requirements.length === 0 ? (
              <div style={{
                textAlign: 'center',
                color: '#b7eb8f',
                padding: '32px 0',
                fontSize: '13px'
              }}>
                <PlusOutlined style={{ fontSize: '22px', marginBottom: '8px', color: '#d9d9d9' }} />
                <div>No hay requerimientos</div>
              </div>
            ) : (
              requirements.map((req, idx) => (
                <div className="summary-row" key={req.key}>
                  <div className="col-num">{idx + 1}</div>
                  <div className="col-clave" title={req.clave || 'Sin clave'}>
                    {req.clave || <span style={{ color: '#bfbfbf' }}>-</span>}
                  </div>
                  <div className="col-desc" title={req.description || ''}>
                    {req.description || <span style={{ color: '#bfbfbf' }}>-</span>}
                  </div>
                  <div className="col-cant">{req.quantity}</div>
                  <div className="col-total">${req.totalPrice.toLocaleString()}</div>
                  <div className="col-action">
                    <Button
                      type="text"
                      danger
                      icon={<DeleteOutlined />}
                      size="small"
                      onClick={() => removeRequirement(req.key)}
                    />
                  </div>
                </div>
              ))
            )}
          </SummaryTable>

          {requirements.length > 0 && (
            <PanelFooter>
              <Typography.Text style={{ color: '#595959' }}>
                Total: {requirements.length} requerimiento{requirements.length !== 1 ? 's' : ''}
              </Typography.Text>
              <br />
              <Typography.Text style={{ fontWeight: 600, color: '#52c41a' }}>
                Subtotal: ${requirements.reduce((sum: number, req: RequirementItem) => sum + req.totalPrice, 0).toLocaleString()}
              </Typography.Text>
            </PanelFooter>
          )}
        </PanelContent>
      </SidePanel>
    </MainContainer>
  );
};

export default EmergencyPurchaseForm;
