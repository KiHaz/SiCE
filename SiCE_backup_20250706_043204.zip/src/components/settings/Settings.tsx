import React, { useState } from 'react';
import { 
  Card, 
  Tabs, 
  Typography, 
  Space, 
  Switch, 
  Form, 
  Input, 
  Button, 
  Select, 
  InputNumber,
  message,
  Divider,
  Alert
} from 'antd';
import { 
  SettingOutlined, 
  DatabaseOutlined, 
  SecurityScanOutlined, 
  BellOutlined, 
  GlobalOutlined,
  SaveOutlined
} from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import SystemStorage from './SystemStorage';

const { Title, Paragraph } = Typography;
const { TabPane } = Tabs;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
`;

const HeaderCard = styled(StyledCard)`
  margin-bottom: 24px;
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  border: 1px solid rgba(82, 196, 26, 0.2);
`;

const TabContainer = styled(StyledCard)`
  .ant-tabs-tab {
    font-weight: 500;
    
    &:hover {
      color: #52c41a;
    }
  }
  
  .ant-tabs-tab-active {
    color: #52c41a;
  }
  
  .ant-tabs-ink-bar {
    background: #52c41a;
  }
`;

const SettingsForm = styled(Form)`
  .ant-form-item-label > label {
    font-weight: 500;
    color: #262626;
  }
`;

const Settings: React.FC = () => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState({
    // Configuración general
    systemName: 'SiCE - Sistema de Compras Emergentes',
    systemDescription: 'Sistema para gestión de compras emergentes',
    language: 'es',
    timezone: 'America/Mexico_City',
    
    // Configuración de seguridad
    passwordMinLength: 4,
    passwordRequireSymbols: false,
    passwordRequireNumbers: false,
    passwordRequireUppercase: false,
    sessionTimeout: 30,
    maxLoginAttempts: 5,
    
    // Configuración de notificaciones
    emailNotifications: true,
    pushNotifications: true,
    systemAlerts: true,
    
    // Configuración de la aplicación
    autoSave: true,
    autoLogout: true,
    showTutorials: true,
    compactMode: false
  });

  const handleSaveSettings = async (values: any) => {
    setLoading(true);
    try {
      // Simular guardado de configuración
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setSettings({ ...settings, ...values });
      localStorage.setItem('sice-settings', JSON.stringify({ ...settings, ...values }));
      
      message.success('Configuración guardada exitosamente');
    } catch (error) {
      message.error('Error al guardar la configuración');
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    // Cargar configuración guardada
    const savedSettings = localStorage.getItem('sice-settings');
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings({ ...settings, ...parsed });
        form.setFieldsValue(parsed);
      } catch (error) {
        console.error('Error al cargar configuración:', error);
      }
    }
  }, []);

  const generalSettings = (
    <SettingsForm
      form={form}
      layout="vertical"
      onFinish={handleSaveSettings}
      initialValues={settings}
    >
      <Alert
        message="Configuración General"
        description="Estos ajustes afectan el comportamiento general del sistema."
        type="info"
        showIcon
        style={{ marginBottom: 16 }}
      />
      
      <Form.Item
        label="Nombre del Sistema"
        name="systemName"
        rules={[{ required: true, message: 'El nombre del sistema es requerido' }]}
      >
        <Input placeholder="Nombre del sistema" />
      </Form.Item>

      <Form.Item
        label="Descripción"
        name="systemDescription"
      >
        <Input.TextArea rows={3} placeholder="Descripción del sistema" />
      </Form.Item>

      <Form.Item
        label="Idioma"
        name="language"
      >
        <Select>
          <Select.Option value="es">Español</Select.Option>
          <Select.Option value="en">English</Select.Option>
        </Select>
      </Form.Item>

      <Form.Item
        label="Zona Horaria"
        name="timezone"
      >
        <Select>
          <Select.Option value="America/Mexico_City">Ciudad de México</Select.Option>
          <Select.Option value="America/New_York">Nueva York</Select.Option>
          <Select.Option value="Europe/Madrid">Madrid</Select.Option>
        </Select>
      </Form.Item>

      <Divider />

      <Space>
        <Form.Item label="Guardado automático" name="autoSave" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item label="Cierre automático" name="autoLogout" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item label="Mostrar tutoriales" name="showTutorials" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item label="Modo compacto" name="compactMode" valuePropName="checked">
          <Switch />
        </Form.Item>
      </Space>

      <Form.Item>
        <Button type="primary" htmlType="submit" loading={loading} icon={<SaveOutlined />}>
          Guardar Configuración
        </Button>
      </Form.Item>
    </SettingsForm>
  );

  const securitySettings = (
    <SettingsForm
      form={form}
      layout="vertical"
      onFinish={handleSaveSettings}
      initialValues={settings}
    >
      <Alert
        message="Configuración de Seguridad"
        description="Ajusta los parámetros de seguridad del sistema."
        type="warning"
        showIcon
        style={{ marginBottom: 16 }}
      />
      
      <Form.Item
        label="Longitud mínima de contraseña"
        name="passwordMinLength"
        rules={[{ required: true, message: 'La longitud mínima es requerida' }]}
      >
        <InputNumber min={4} max={20} />
      </Form.Item>

      <Form.Item
        label="Tiempo de sesión (minutos)"
        name="sessionTimeout"
        rules={[{ required: true, message: 'El tiempo de sesión es requerido' }]}
      >
        <InputNumber min={5} max={120} />
      </Form.Item>

      <Form.Item
        label="Máximo intentos de login"
        name="maxLoginAttempts"
        rules={[{ required: true, message: 'El máximo de intentos es requerido' }]}
      >
        <InputNumber min={3} max={10} />
      </Form.Item>

      <Divider />

      <Title level={5}>Requisitos de Contraseña</Title>
      <Space direction="vertical">
        <Form.Item label="Requerir símbolos" name="passwordRequireSymbols" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item label="Requerir números" name="passwordRequireNumbers" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item label="Requerir mayúsculas" name="passwordRequireUppercase" valuePropName="checked">
          <Switch />
        </Form.Item>
      </Space>

      <Form.Item>
        <Button type="primary" htmlType="submit" loading={loading} icon={<SaveOutlined />}>
          Guardar Configuración
        </Button>
      </Form.Item>
    </SettingsForm>
  );

  const notificationSettings = (
    <SettingsForm
      form={form}
      layout="vertical"
      onFinish={handleSaveSettings}
      initialValues={settings}
    >
      <Alert
        message="Configuración de Notificaciones"
        description="Controla cómo y cuándo recibir notificaciones del sistema."
        type="info"
        showIcon
        style={{ marginBottom: 16 }}
      />
      
      <Space direction="vertical" style={{ width: '100%' }}>
        <Form.Item label="Notificaciones por email" name="emailNotifications" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item label="Notificaciones push" name="pushNotifications" valuePropName="checked">
          <Switch />
        </Form.Item>
        <Form.Item label="Alertas del sistema" name="systemAlerts" valuePropName="checked">
          <Switch />
        </Form.Item>
      </Space>

      <Form.Item>
        <Button type="primary" htmlType="submit" loading={loading} icon={<SaveOutlined />}>
          Guardar Configuración
        </Button>
      </Form.Item>
    </SettingsForm>
  );

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <HeaderCard>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <Title level={2} style={{ margin: 0, color: '#52c41a' }}>
                <SettingOutlined style={{ marginRight: 8 }} />
                Configuración del Sistema
              </Title>
              <Paragraph style={{ margin: '8px 0 0', color: '#666' }}>
                Personaliza el comportamiento y la seguridad del sistema
              </Paragraph>
            </div>
          </div>
        </HeaderCard>

        <TabContainer>
          <Tabs defaultActiveKey="general" type="card">
            <TabPane 
              tab={
                <span>
                  <GlobalOutlined />
                  General
                </span>
              } 
              key="general"
            >
              {generalSettings}
            </TabPane>
            
            <TabPane 
              tab={
                <span>
                  <SecurityScanOutlined />
                  Seguridad
                </span>
              } 
              key="security"
            >
              {securitySettings}
            </TabPane>
            
            <TabPane 
              tab={
                <span>
                  <BellOutlined />
                  Notificaciones
                </span>
              } 
              key="notifications"
            >
              {notificationSettings}
            </TabPane>
            
            <TabPane 
              tab={
                <span>
                  <DatabaseOutlined />
                  Almacenamiento
                </span>
              } 
              key="storage"
            >
              <SystemStorage />
            </TabPane>
          </Tabs>
        </TabContainer>
      </motion.div>
    </div>
  );
};

export default Settings;
