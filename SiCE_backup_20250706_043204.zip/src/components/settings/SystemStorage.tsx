import React, { useState } from 'react';
import { 
  Card, 
  Button, 
  Typography, 
  Space, 
  message, 
  Upload,
  Divider,
  Statistic,
  Row,
  Col,
  Alert,
  Popconfirm
} from 'antd';
import { 
  DownloadOutlined,
  UploadOutlined,
  DeleteOutlined,
  ReloadOutlined,
  FileTextOutlined,
  DatabaseOutlined,
  UserOutlined,
  SecurityScanOutlined
} from '@ant-design/icons';
import styled from '@emotion/styled';
import { motion } from 'framer-motion';
import { userStorage } from '../../services/userStorage';

const { Title, Paragraph } = Typography;

const StyledCard = styled(Card)`
  border: 1px solid rgba(82, 196, 26, 0.1);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
  margin-bottom: 24px;
`;

const HeaderCard = styled(StyledCard)`
  background: linear-gradient(135deg, rgba(82, 196, 26, 0.1), rgba(115, 209, 61, 0.1));
  border: 1px solid rgba(82, 196, 26, 0.2);
`;

const DangerCard = styled(StyledCard)`
  border-color: #ff4d4f;
  
  .ant-card-head {
    background: rgba(255, 77, 79, 0.1);
    border-bottom: 1px solid rgba(255, 77, 79, 0.2);
  }
`;

const ActionButton = styled(Button)`
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
`;

const SystemStorage: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeUsers: 0,
    totalCredentials: 0,
    lastBackup: null as string | null
  });

  React.useEffect(() => {
    loadStats();
  }, []);

  const loadStats = () => {
    try {
      const users = userStorage.getUsers();
      const activeUsers = users.filter(u => u.isActive).length;
      
      setStats({
        totalUsers: users.length,
        activeUsers,
        totalCredentials: users.length, // Cada usuario tiene credenciales
        lastBackup: localStorage.getItem('sice-last-backup')
      });
    } catch (error) {
      message.error('Error al cargar estadísticas');
    }
  };

  const handleExportData = () => {
    setLoading(true);
    try {
      const data = userStorage.exportData();
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sice-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      // Guardar fecha del último backup
      localStorage.setItem('sice-last-backup', new Date().toISOString());
      loadStats();
      
      message.success('Datos exportados exitosamente');
    } catch (error) {
      message.error('Error al exportar datos');
    } finally {
      setLoading(false);
    }
  };

  const handleImportData = (file: File) => {
    setLoading(true);
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = e.target?.result as string;
        userStorage.importData(data);
        loadStats();
        message.success('Datos importados exitosamente');
      } catch (error) {
        message.error('Error al importar datos. Verifica el formato del archivo.');
      } finally {
        setLoading(false);
      }
    };
    
    reader.readAsText(file);
    return false; // Prevent default upload
  };

  const handleResetData = () => {
    setLoading(true);
    try {
      userStorage.resetToDefaults();
      loadStats();
      message.success('Datos restablecidos a valores por defecto');
    } catch (error) {
      message.error('Error al restablecer datos');
    } finally {
      setLoading(false);
    }
  };

  const handleClearAll = () => {
    setLoading(true);
    try {
      userStorage.clearAll();
      loadStats();
      message.success('Todos los datos han sido eliminados');
    } catch (error) {
      message.error('Error al eliminar datos');
    } finally {
      setLoading(false);
    }
  };

  const uploadProps = {
    beforeUpload: handleImportData,
    showUploadList: false,
    accept: '.json'
  };

  return (
    <div>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <HeaderCard>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <Title level={2} style={{ margin: 0, color: '#52c41a' }}>
                <DatabaseOutlined style={{ marginRight: 8 }} />
                Sistema de Almacenamiento
              </Title>
              <Paragraph style={{ margin: '8px 0 0', color: '#666' }}>
                Gestiona el almacenamiento de usuarios, credenciales y datos del sistema
              </Paragraph>
            </div>
          </div>
        </HeaderCard>

        <Row gutter={[16, 16]}>
          <Col xs={24} sm={12} md={6}>
            <StyledCard>
              <Statistic
                title="Total de Usuarios"
                value={stats.totalUsers}
                prefix={<UserOutlined />}
                valueStyle={{ color: '#52c41a' }}
              />
            </StyledCard>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <StyledCard>
              <Statistic
                title="Usuarios Activos"
                value={stats.activeUsers}
                prefix={<UserOutlined />}
                valueStyle={{ color: '#1890ff' }}
              />
            </StyledCard>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <StyledCard>
              <Statistic
                title="Credenciales"
                value={stats.totalCredentials}
                prefix={<SecurityScanOutlined />}
                valueStyle={{ color: '#fa8c16' }}
              />
            </StyledCard>
          </Col>
          <Col xs={24} sm={12} md={6}>
            <StyledCard>
              <Statistic
                title="Último Backup"
                value={stats.lastBackup ? 
                  new Date(stats.lastBackup).toLocaleDateString() : 
                  'Nunca'
                }
                prefix={<FileTextOutlined />}
                valueStyle={{ color: '#722ed1' }}
              />
            </StyledCard>
          </Col>
        </Row>

        <StyledCard title="Gestión de Datos">
          <Alert
            message="Información importante"
            description="Estas funciones afectan todos los datos del sistema. Asegúrate de hacer un backup antes de realizar cambios importantes."
            type="info"
            showIcon
            style={{ marginBottom: 16 }}
          />
          
          <Space direction="vertical" style={{ width: '100%' }}>
            <div>
              <Title level={4}>Exportar Datos</Title>
              <Paragraph type="secondary">
                Descarga una copia de seguridad de todos los usuarios y credenciales.
              </Paragraph>
              <ActionButton 
                type="primary"
                icon={<DownloadOutlined />}
                onClick={handleExportData}
                loading={loading}
              >
                Exportar Datos
              </ActionButton>
            </div>
            
            <Divider />
            
            <div>
              <Title level={4}>Importar Datos</Title>
              <Paragraph type="secondary">
                Restaura los datos desde un archivo de backup previamente exportado.
              </Paragraph>
              <Upload {...uploadProps}>
                <ActionButton 
                  icon={<UploadOutlined />}
                  loading={loading}
                >
                  Seleccionar Archivo
                </ActionButton>
              </Upload>
            </div>
          </Space>
        </StyledCard>

        <DangerCard title="Zona de Peligro">
          <Alert
            message="¡Atención!"
            description="Las siguientes acciones son irreversibles y pueden eliminar todos los datos del sistema."
            type="warning"
            showIcon
            style={{ marginBottom: 16 }}
          />
          
          <Space direction="vertical" style={{ width: '100%' }}>
            <div>
              <Title level={4}>Restablecer a Valores por Defecto</Title>
              <Paragraph type="secondary">
                Elimina todos los datos y restaura únicamente la cuenta de administrador.
              </Paragraph>
              <Popconfirm
                title="¿Estás seguro?"
                description="Esta acción eliminará todos los usuarios excepto el administrador."
                onConfirm={handleResetData}
                okText="Sí"
                cancelText="No"
              >
                <ActionButton 
                  type="primary"
                  danger
                  icon={<ReloadOutlined />}
                  loading={loading}
                >
                  Restablecer Sistema
                </ActionButton>
              </Popconfirm>
            </div>
            
            <Divider />
            
            <div>
              <Title level={4}>Eliminar Todos los Datos</Title>
              <Paragraph type="secondary">
                Elimina completamente todos los datos del sistema, incluyendo el administrador.
              </Paragraph>
              <Popconfirm
                title="¿Estás completamente seguro?"
                description="Esta acción eliminará TODOS los datos. No podrás iniciar sesión hasta crear nuevos usuarios."
                onConfirm={handleClearAll}
                okText="Sí, eliminar todo"
                cancelText="Cancelar"
              >
                <ActionButton 
                  type="primary"
                  danger
                  icon={<DeleteOutlined />}
                  loading={loading}
                >
                  Eliminar Todo
                </ActionButton>
              </Popconfirm>
            </div>
          </Space>
        </DangerCard>
      </motion.div>
    </div>
  );
};

export default SystemStorage;
