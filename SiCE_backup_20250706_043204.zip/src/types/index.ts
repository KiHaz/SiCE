// Tipos e interfaces para el sistema de usuarios y perfiles

export interface User {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  permissions: Permission[];
  avatar?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  lastLogin?: Date;
}

export interface UserRole {
  id: string;
  name: string;
  displayName: string;
  description: string;
  level: number; // 1 = Super Admin, 2 = Admin, 3 = Manager, 4 = User
  color: string;
}

export interface Permission {
  id: string;
  name: string;
  displayName: string;
  description: string;
  module: string;
  actions: PermissionAction[];
}

export interface PermissionAction {
  action: 'create' | 'read' | 'update' | 'delete' | 'manage';
  allowed: boolean;
}

export interface CreateUserForm {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  password: string;
  confirmPassword: string;
  roleId: string;
  permissions: string[];
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  token: string | null;
}

// Módulos del sistema
export const SYSTEM_MODULES = {
  DASHBOARD: 'dashboard',
  USERS: 'users',
  PROFILES: 'profiles',
  PURCHASES: 'purchases',
  INVENTORY: 'inventory',
  REPORTS: 'reports',
  SETTINGS: 'settings',
  AUDIT: 'audit'
} as const;

// Roles predefinidos
export const DEFAULT_ROLES: UserRole[] = [
  {
    id: '1',
    name: 'super_admin',
    displayName: 'Super Administrador',
    description: 'Acceso completo al sistema',
    level: 1,
    color: '#ff4d4f'
  },
  {
    id: '2', 
    name: 'admin',
    displayName: 'Administrador',
    description: 'Administrador del sistema con permisos completos',
    level: 2,
    color: '#52c41a'
  },
  {
    id: '3',
    name: 'manager',
    displayName: 'Gerente',
    description: 'Gestión de compras y reportes',
    level: 3,
    color: '#1890ff'
  },
  {
    id: '4',
    name: 'user',
    displayName: 'Usuario',
    description: 'Usuario básico del sistema',
    level: 4,
    color: '#faad14'
  }
];

// Permisos predefinidos
export const DEFAULT_PERMISSIONS: Permission[] = [
  {
    id: '1',
    name: 'dashboard_access',
    displayName: 'Acceso al Dashboard',
    description: 'Permite acceder al panel principal',
    module: SYSTEM_MODULES.DASHBOARD,
    actions: [{ action: 'read', allowed: true }]
  },
  {
    id: '2',
    name: 'users_management',
    displayName: 'Gestión de Usuarios',
    description: 'Crear, editar, eliminar usuarios',
    module: SYSTEM_MODULES.USERS,
    actions: [
      { action: 'create', allowed: true },
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'delete', allowed: true },
      { action: 'manage', allowed: true }
    ]
  },
  {
    id: '3',
    name: 'profiles_management',
    displayName: 'Gestión de Perfiles',
    description: 'Gestionar perfiles y roles',
    module: SYSTEM_MODULES.PROFILES,
    actions: [
      { action: 'create', allowed: true },
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'delete', allowed: true }
    ]
  },
  {
    id: '4',
    name: 'purchases_management',
    displayName: 'Gestión de Compras',
    description: 'Gestionar compras emergentes',
    module: SYSTEM_MODULES.PURCHASES,
    actions: [
      { action: 'create', allowed: true },
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'delete', allowed: true }
    ]
  },
  {
    id: '5',
    name: 'inventory_management',
    displayName: 'Gestión de Inventario',
    description: 'Control de inventario y stock',
    module: SYSTEM_MODULES.INVENTORY,
    actions: [
      { action: 'create', allowed: true },
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'delete', allowed: true }
    ]
  },
  {
    id: '6',
    name: 'reports_access',
    displayName: 'Acceso a Reportes',
    description: 'Ver y generar reportes',
    module: SYSTEM_MODULES.REPORTS,
    actions: [
      { action: 'read', allowed: true },
      { action: 'create', allowed: true }
    ]
  },
  {
    id: '7',
    name: 'settings_management',
    displayName: 'Configuración del Sistema',
    description: 'Configurar parámetros del sistema',
    module: SYSTEM_MODULES.SETTINGS,
    actions: [
      { action: 'read', allowed: true },
      { action: 'update', allowed: true },
      { action: 'manage', allowed: true }
    ]
  },
  {
    id: '8',
    name: 'audit_access',
    displayName: 'Auditoría',
    description: 'Acceso a logs de auditoría',
    module: SYSTEM_MODULES.AUDIT,
    actions: [{ action: 'read', allowed: true }]
  }
];

export type SystemModule = typeof SYSTEM_MODULES[keyof typeof SYSTEM_MODULES];
