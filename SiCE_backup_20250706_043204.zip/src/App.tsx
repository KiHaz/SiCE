import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ConfigProvider } from 'antd';
import { Global } from '@emotion/react';
import esES from 'antd/es/locale/es_ES';
import theme from './styles/theme';
import globalStyles from './styles/GlobalStyles';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Login from './components/auth/Login';
import ProtectedRoute from './components/auth/ProtectedRoute';
import DashboardLayout from './components/layout/DashboardLayout';
import Dashboard from './components/dashboard/Dashboard';
import ProfileManagement from './components/profiles/ProfileManagement';
import CreateProfile from './components/profiles/CreateProfile';
import ViewProfile from './components/profiles/ViewProfile';
import EditProfile from './components/profiles/EditProfile';
import Settings from './components/settings/Settings';
import EmergencyPurchaseForm from './components/purchases/EmergencyPurchaseForm';

const AppContent: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Routes>
      <Route 
        path="/login" 
        element={
          isAuthenticated ? <Navigate to="/dashboard" replace /> : <Login />
        } 
      />
      <Route 
        path="/dashboard" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <Dashboard />
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/profiles" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <ProfileManagement />
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/profiles/create" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <CreateProfile />
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/profiles/view/:id" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <ViewProfile />
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/profiles/edit/:id" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <EditProfile />
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/emergency-purchases" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <EmergencyPurchaseForm />
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/settings" 
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <Settings />
            </DashboardLayout>
          </ProtectedRoute>
        } 
      />
      <Route 
        path="/" 
        element={
          isAuthenticated ? <Navigate to="/dashboard" replace /> : <Navigate to="/login" replace />
        } 
      />
      <Route 
        path="*" 
        element={
          isAuthenticated ? <Navigate to="/dashboard" replace /> : <Navigate to="/login" replace />
        } 
      />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <ConfigProvider theme={theme} locale={esES}>
      <Global styles={globalStyles} />
      <Router>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </Router>
    </ConfigProvider>
  );
};

export default App;
