/* Estilos globales para SiCE */
import { css } from '@emotion/react';

export const globalStyles = css`
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  html, body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    background: #f0f2f5;
    font-size: 14px;
    line-height: 1.5;
    overflow-x: hidden;
  }

  /* Responsive font sizes */
  @media (max-width: 320px) {
    html, body {
      font-size: 12px;
    }
  }

  @media (min-width: 321px) and (max-width: 375px) {
    html, body {
      font-size: 13px;
    }
  }

  @media (min-width: 376px) and (max-width: 768px) {
    html, body {
      font-size: 14px;
    }
  }

  @media (min-width: 769px) and (max-width: 1024px) {
    html, body {
      font-size: 15px;
    }
  }

  @media (min-width: 1025px) {
    html, body {
      font-size: 16px;
    }
  }

  #root {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
  }

  /* Gradientes personalizados */
  .gradient-bg {
    background: linear-gradient(135deg, #ffffff 0%, #f6ffed 50%, #d9f7be 100%);
  }

  .gradient-primary {
    background: linear-gradient(135deg, #52c41a 0%, #73d13d 100%);
  }

  .gradient-light {
    background: linear-gradient(135deg, #ffffff 0%, #f0f2f5 100%);
  }

  /* Efectos de glassmorphism */
  .glass-effect {
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    background: rgba(255, 255, 255, 0.8);
    border: 1px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  }

  /* Animaciones personalizadas */
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes fadeInDown {
    from {
      opacity: 0;
      transform: translateY(-20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes fadeInLeft {
    from {
      opacity: 0;
      transform: translateX(-20px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes fadeInRight {
    from {
      opacity: 0;
      transform: translateX(20px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes scaleIn {
    from {
      opacity: 0;
      transform: scale(0.9);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes pulse {
    0% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.05);
    }
    100% {
      transform: scale(1);
    }
  }

  /* Clases de animación */
  .animate-fadeInUp {
    animation: fadeInUp 0.6s ease-out;
  }

  .animate-fadeInDown {
    animation: fadeInDown 0.6s ease-out;
  }

  .animate-fadeInLeft {
    animation: fadeInLeft 0.6s ease-out;
  }

  .animate-fadeInRight {
    animation: fadeInRight 0.6s ease-out;
  }

  .animate-scaleIn {
    animation: scaleIn 0.4s ease-out;
  }

  .animate-pulse {
    animation: pulse 2s infinite;
  }

  /* Efectos hover */
  .hover-lift {
    transition: all 0.3s ease;
  }

  .hover-lift:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  }

  .hover-glow {
    transition: all 0.3s ease;
  }

  .hover-glow:hover {
    box-shadow: 0 0 20px rgba(82, 196, 26, 0.3);
  }

  /* Scrollbar personalizada */
  ::-webkit-scrollbar {
    width: 8px;
  }

  ::-webkit-scrollbar-track {
    background: #f0f2f5;
  }

  ::-webkit-scrollbar-thumb {
    background: #d9d9d9;
    border-radius: 4px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: #bfbfbf;
  }

  /* Responsive design helpers */
  
  /* Breakpoints */
  /* XS: 0-319px (muy pequeño) */
  /* SM: 320-575px (móvil pequeño) */
  /* MD: 576-767px (móvil grande) */
  /* LG: 768-1023px (tablet) */
  /* XL: 1024-1439px (desktop) */
  /* XXL: 1440px+ (desktop grande) */

  /* Visibility helpers */
  @media (max-width: 319px) {
    .xs-hidden { display: none !important; }
  }

  @media (min-width: 320px) and (max-width: 575px) {
    .sm-hidden { display: none !important; }
  }

  @media (min-width: 576px) and (max-width: 767px) {
    .md-hidden { display: none !important; }
  }

  @media (max-width: 767px) {
    .mobile-hidden { display: none !important; }
    .mobile-full-width { width: 100% !important; }
    .mobile-center { text-align: center !important; }
    .mobile-padding { padding: 16px !important; }
    .mobile-margin { margin: 16px !important; }
  }

  @media (min-width: 768px) and (max-width: 1023px) {
    .lg-hidden { display: none !important; }
    .tablet-hidden { display: none !important; }
  }

  @media (min-width: 1024px) and (max-width: 1439px) {
    .xl-hidden { display: none !important; }
  }

  @media (min-width: 1440px) {
    .xxl-hidden { display: none !important; }
  }

  @media (min-width: 768px) {
    .desktop-hidden { display: none !important; }
  }

  /* Touch-friendly helpers */
  @media (hover: none) and (pointer: coarse) {
    .touch-large {
      min-height: 44px !important;
      min-width: 44px !important;
    }
    
    .touch-padding {
      padding: 12px !important;
    }
  }

  /* High DPI / Retina display helpers */
  @media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
    .retina-border {
      border-width: 0.5px !important;
    }
  }

  /* Utilidades de espaciado */
  .mt-0 { margin-top: 0 !important; }
  .mt-1 { margin-top: 8px !important; }
  .mt-2 { margin-top: 16px !important; }
  .mt-3 { margin-top: 24px !important; }
  .mt-4 { margin-top: 32px !important; }
  .mt-5 { margin-top: 40px !important; }

  .mb-0 { margin-bottom: 0 !important; }
  .mb-1 { margin-bottom: 8px !important; }
  .mb-2 { margin-bottom: 16px !important; }
  .mb-3 { margin-bottom: 24px !important; }
  .mb-4 { margin-bottom: 32px !important; }
  .mb-5 { margin-bottom: 40px !important; }

  .p-0 { padding: 0 !important; }
  .p-1 { padding: 8px !important; }
  .p-2 { padding: 16px !important; }
  .p-3 { padding: 24px !important; }
  .p-4 { padding: 32px !important; }
  .p-5 { padding: 40px !important; }

  /* Utilidades de texto */
  .text-center { text-align: center !important; }
  .text-left { text-align: left !important; }
  .text-right { text-align: right !important; }

  .text-primary { color: #52c41a !important; }
  .text-secondary { color: #8c8c8c !important; }
  .text-success { color: #52c41a !important; }
  .text-warning { color: #faad14 !important; }
  .text-error { color: #ff4d4f !important; }

  /* Utilidades de flexbox */
  .flex { display: flex !important; }
  .flex-col { flex-direction: column !important; }
  .flex-row { flex-direction: row !important; }
  .flex-center { justify-content: center !important; align-items: center !important; }
  .flex-between { justify-content: space-between !important; }
  .flex-around { justify-content: space-around !important; }
  .flex-evenly { justify-content: space-evenly !important; }
  .flex-wrap { flex-wrap: wrap !important; }
  .flex-nowrap { flex-wrap: nowrap !important; }

  .items-center { align-items: center !important; }
  .items-start { align-items: flex-start !important; }
  .items-end { align-items: flex-end !important; }
  .items-stretch { align-items: stretch !important; }

  .justify-center { justify-content: center !important; }
  .justify-start { justify-content: flex-start !important; }
  .justify-end { justify-content: flex-end !important; }
  .justify-between { justify-content: space-between !important; }
  .justify-around { justify-content: space-around !important; }

  /* Utilidades de posicionamiento */
  .relative { position: relative !important; }
  .absolute { position: absolute !important; }
  .fixed { position: fixed !important; }
  .sticky { position: sticky !important; }

  .top-0 { top: 0 !important; }
  .right-0 { right: 0 !important; }
  .bottom-0 { bottom: 0 !important; }
  .left-0 { left: 0 !important; }

  /* Utilidades de visibilidad */
  .visible { visibility: visible !important; }
  .invisible { visibility: hidden !important; }
  .opacity-0 { opacity: 0 !important; }
  .opacity-50 { opacity: 0.5 !important; }
  .opacity-100 { opacity: 1 !important; }

  /* Utilidades de tamaño */
  .w-full { width: 100% !important; }
  .w-auto { width: auto !important; }
  .h-full { height: 100% !important; }
  .h-auto { height: auto !important; }
  .h-screen { height: 100vh !important; }
  .min-h-screen { min-height: 100vh !important; }

  /* Utilidades de overflow */
  .overflow-hidden { overflow: hidden !important; }
  .overflow-visible { overflow: visible !important; }
  .overflow-scroll { overflow: scroll !important; }
  .overflow-auto { overflow: auto !important; }

  /* Utilidades de z-index */
  .z-0 { z-index: 0 !important; }
  .z-10 { z-index: 10 !important; }
  .z-20 { z-index: 20 !important; }
  .z-30 { z-index: 30 !important; }
  .z-40 { z-index: 40 !important; }
  .z-50 { z-index: 50 !important; }
  .z-auto { z-index: auto !important; }

  /* Utilidades de cursor */
  .cursor-pointer { cursor: pointer !important; }
  .cursor-not-allowed { cursor: not-allowed !important; }
  .cursor-default { cursor: default !important; }
  .cursor-move { cursor: move !important; }
  .cursor-text { cursor: text !important; }

  /* Utilidades de selección */
  .select-none { user-select: none !important; }
  .select-text { user-select: text !important; }
  .select-all { user-select: all !important; }
  .select-auto { user-select: auto !important; }
`;

export default globalStyles;
