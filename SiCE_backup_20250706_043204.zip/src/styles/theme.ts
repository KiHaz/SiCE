import type { ThemeConfig } from 'antd';

export const theme: ThemeConfig = {
  token: {
    // Colores primarios - Gradiente blanco-verde
    colorPrimary: '#52c41a',
    colorPrimaryBg: '#f6ffed',
    colorPrimaryBgHover: '#d9f7be',
    colorPrimaryBorder: '#b7eb8f',
    colorPrimaryBorderHover: '#95de64',
    colorPrimaryHover: '#73d13d',
    colorPrimaryActive: '#389e0d',
    colorPrimaryTextHover: '#73d13d',
    colorPrimaryText: '#52c41a',
    colorPrimaryTextActive: '#389e0d',
    
    // Colores secundarios
    colorSuccess: '#52c41a',
    colorInfo: '#1890ff',
    colorWarning: '#faad14',
    colorError: '#ff4d4f',
    
    // Colores de fondo
    colorBgBase: '#ffffff',
    colorBgContainer: '#ffffff',
    colorBgElevated: '#ffffff',
    colorBgLayout: '#f0f2f5',
    colorBgSpotlight: '#ffffff',
    colorBgMask: 'rgba(0, 0, 0, 0.45)',
    
    // Bordes y sombras - Responsive
    borderRadius: 6,
    borderRadiusLG: 10,
    borderRadiusSM: 4,
    borderRadiusXS: 2,
    
    // Espaciado - Responsive
    padding: 12,
    paddingLG: 20,
    paddingSM: 8,
    paddingXS: 4,
    
    // Tipografía - Responsive
    fontFamily: `-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji'`,
    fontSize: 13,
    fontSizeLG: 15,
    fontSizeSM: 11,
    fontSizeXL: 18,
    fontWeightStrong: 600,
    
    // Breakpoints y espaciado responsive
    screenXS: 480,
    screenSM: 576,
    screenMD: 768,
    screenLG: 992,
    screenXL: 1200,
    screenXXL: 1600,
    
    // Efectos
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)',
    boxShadowSecondary: '0 4px 12px rgba(0, 0, 0, 0.08)',
    boxShadowTertiary: '0 6px 16px rgba(0, 0, 0, 0.12)',
    
    // Líneas
    lineWidth: 1,
    lineType: 'solid',
    
    // Colores de texto
    colorText: '#262626',
    colorTextSecondary: '#8c8c8c',
    colorTextTertiary: '#bfbfbf',
    colorTextQuaternary: '#d9d9d9',
    
    // Movimiento
    motionDurationFast: '0.1s',
    motionDurationMid: '0.2s',
    motionDurationSlow: '0.3s',
    motionEaseInOut: 'cubic-bezier(0.645, 0.045, 0.355, 1)',
    motionEaseInOutCirc: 'cubic-bezier(0.78, 0.14, 0.15, 0.86)',
    motionEaseOut: 'cubic-bezier(0.215, 0.61, 0.355, 1)',
    motionEaseInQuint: 'cubic-bezier(0.755, 0.05, 0.855, 0.06)',
    motionEaseOutQuint: 'cubic-bezier(0.23, 1, 0.32, 1)',
  },
  components: {
    Button: {
      borderRadius: 6,
      controlHeight: 36,
      controlHeightLG: 44,
      controlHeightSM: 32,
      fontWeight: 500,
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.06)',
      primaryShadow: '0 2px 4px rgba(82, 196, 26, 0.15)',
    },
    Input: {
      borderRadius: 6,
      controlHeight: 36,
      controlHeightLG: 44,
      controlHeightSM: 32,
      paddingInline: 10,
      paddingInlineLG: 14,
      paddingInlineSM: 8,
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.02)',
      activeShadow: '0 0 0 2px rgba(82, 196, 26, 0.2)',
    },
    Card: {
      borderRadius: 10,
      borderRadiusLG: 12,
      borderRadiusSM: 8,
      boxShadow: '0 4px 12px rgba(0, 0, 0, 0.08)',
      headerBg: '#fafafa',
      paddingLG: 20,
      padding: 16,
      paddingSM: 12,
    },
    Form: {
      itemMarginBottom: 16,
      verticalLabelPadding: '0 0 6px',
    },
    Typography: {
      titleMarginBottom: '0.4em',
      titleMarginTop: '1em',
    },
    Layout: {
      headerBg: '#ffffff',
      headerPadding: '0 16px',
      siderBg: '#ffffff',
      bodyBg: '#f0f2f5',
    },
    Menu: {
      itemBg: 'transparent',
      itemSelectedBg: '#f6ffed',
      itemActiveBg: '#d9f7be',
      itemSelectedColor: '#52c41a',
      itemColor: '#262626',
    },
    Space: {
      size: 8,
      sizeMS: 4,
      sizeSM: 8,
      sizeLG: 16,
      sizeXL: 24,
    },
    Divider: {
      margin: 16,
      marginLG: 24,
      marginSM: 12,
    },
  },
  algorithm: undefined, // Usaremos el algoritmo por defecto
};

export default theme;
