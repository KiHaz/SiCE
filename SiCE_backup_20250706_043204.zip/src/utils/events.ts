import React from 'react';
import { message } from 'antd';

/**
 * Evento personalizado para notificar cambios en el almacenamiento de usuarios
 */
export const USER_STORAGE_EVENTS = {
  USER_UPDATED: 'user-updated',
  USER_DELETED: 'user-deleted',
  USER_CREATED: 'user-created',
  STORAGE_CHANGED: 'storage-changed'
} as const;

/**
 * Emite un evento personalizado cuando cambia el almacenamiento de usuarios
 */
export const emitUserStorageEvent = (eventType: string, data?: any) => {
  const event = new CustomEvent(eventType, { detail: data });
  window.dispatchEvent(event);
};

/**
 * Hook para escuchar eventos del almacenamiento de usuarios
 */
export const useUserStorageEvents = (callback: (eventType: string, data?: any) => void) => {
  React.useEffect(() => {
    const handleEvent = (event: CustomEvent) => {
      callback(event.type, event.detail);
    };

    // Registrar listeners para todos los eventos
    Object.values(USER_STORAGE_EVENTS).forEach(eventType => {
      window.addEventListener(eventType, handleEvent as EventListener);
    });

    return () => {
      // Limpiar listeners
      Object.values(USER_STORAGE_EVENTS).forEach(eventType => {
        window.removeEventListener(eventType, handleEvent as EventListener);
      });
    };
  }, [callback]);
};

/**
 * Utilidad para mostrar mensajes de notificación
 */
export const showNotification = {
  success: (msg: string) => {
    message.success(msg);
  },
  error: (msg: string) => {
    message.error(msg);
  },
  warning: (msg: string) => {
    message.warning(msg);
  },
  info: (msg: string) => {
    message.info(msg);
  }
};
