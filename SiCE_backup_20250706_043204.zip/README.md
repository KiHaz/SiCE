# SiCE - Sistema de Compras Emergentes

![SiCE Logo](https://img.shields.io/badge/SiCE-Sistema%20de%20Compras%20Emergentes-green)
![React](https://img.shields.io/badge/React-18-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)
![Vite](https://img.shields.io/badge/Vite-5-purple)
![Ant Design](https://img.shields.io/badge/Ant%20Design-5-orange)

## 🚀 Características Principales

- **Interfaz Moderna**: Diseño con efectos glassmorphism y animaciones suaves
- **Completamente Responsive**: Optimizada para dispositivos móviles y escritorio
- **Sistema de Autenticación**: Login seguro con gestión de sesiones
- **Gestión de Usuarios**: Creación, edición y administración de perfiles
- **Almacenamiento Local**: Sistema robusto de almacenamiento de datos
- **Configuración Avanzada**: Panel de configuración con múltiples opciones
- **Backup y Restore**: Funcionalidad completa de exportación e importación de datos

## 🛠️ Tecnologías Utilizadas

- **React 18** - Biblioteca de interfaz de usuario
- **Vite** - Bundler y herramienta de desarrollo
- **TypeScript** - Tipado estático para JavaScript
- **Ant Design** - Biblioteca de componentes UI
- **Emotion** - CSS-in-JS para estilos
- **Framer Motion** - Animaciones y transiciones

## 🏗️ Arquitectura del Sistema

### Estructura de Carpetas

```
src/
├── components/           # Componentes reutilizables
│   ├── auth/            # Autenticación
│   ├── dashboard/       # Dashboard principal
│   ├── layout/          # Componentes de diseño
│   ├── profiles/        # Gestión de perfiles
│   └── settings/        # Configuración del sistema
├── contexts/            # Contextos de React
├── services/            # Servicios y lógica de negocio
│   └── userStorage.ts   # Sistema de almacenamiento
├── styles/              # Estilos globales y tema
├── types/               # Definiciones de TypeScript
└── utils/               # Utilidades y helpers
```

## 💾 Sistema de Almacenamiento

El sistema utiliza **LocalStorage** para persistir datos localmente:

### Características del Sistema de Almacenamiento:

- **Gestión de Usuarios**: CRUD completo de usuarios y perfiles
- **Credenciales Seguras**: Almacenamiento separado de credenciales
- **Roles y Permisos**: Sistema completo de autorización
- **Backup/Restore**: Exportación e importación de datos
- **Singleton Pattern**: Gestión centralizada de datos

### Componentes Principales:

1. **UserStorageManager**: Clase principal para gestión de datos
2. **Usuarios por Defecto**: Sistema con administrador predefinido
3. **Roles del Sistema**: Administrador, Gerente, Usuario, Invitado
4. **Permisos Modulares**: Control granular de acceso

## 🔐 Autenticación

### Credenciales por Defecto:
- **Usuario**: admin
- **Contraseña**: 1234

### Características de Seguridad:
- Validación de credenciales
- Gestión de sesiones
- Roles y permisos
- Protección de rutas

## 📱 Responsive Design

- **Breakpoints**: 576px, 768px, 992px, 1200px
- **Touch-Friendly**: Optimizado para dispositivos táctiles
- **Mobile-First**: Diseño que prioriza dispositivos móviles
- **Layout Adaptativo**: Sidebar colapsable y componentes flexibles

## 🎨 Diseño Visual

### Colores del Tema:
- **Primario**: #52c41a (Verde)
- **Secundario**: #73d13d (Verde claro)
- **Fondo**: Gradiente blanco-verde
- **Efectos**: Glassmorphism y sombras suaves

### Animaciones:
- **Framer Motion**: Transiciones de página
- **Hover Effects**: Efectos interactivos
- **Loading States**: Indicadores de carga
- **Micro-interactions**: Feedback visual

## 🏃‍♂️ Inicio Rápido

1. **Instalar dependencias**:
   ```bash
   npm install
   ```

2. **Ejecutar en desarrollo**:
   ```bash
   npm run dev
   ```

3. **Construir para producción**:
   ```bash
   npm run build
   ```

4. **Previsualizar build**:
   ```bash
   npm run preview
   ```

## 🔧 Configuración

### Variables de Entorno:
- El sistema no requiere variables de entorno adicionales
- Toda la configuración se gestiona a través del panel de configuración

### Personalización:
- Temas: Modificar `src/styles/theme.ts`
- Colores: Ajustar variables CSS en `src/styles/GlobalStyles.ts`
- Componentes: Todos los componentes son modulares y personalizables

## 📊 Gestión de Datos

### Almacenamiento Local:
- **sice-users**: Lista de usuarios del sistema
- **sice-credentials**: Credenciales de acceso
- **sice-user**: Sesión del usuario actual
- **sice-settings**: Configuración del sistema

### Funciones de Administración:
- **Exportar Datos**: Backup completo del sistema
- **Importar Datos**: Restauración desde backup
- **Resetear Sistema**: Vuelta a valores por defecto
- **Limpiar Datos**: Eliminación completa de datos

## 🔍 Funcionalidades

### Dashboard:
- Vista general del sistema
- Estadísticas principales
- Acceso rápido a funciones

### Gestión de Perfiles:
- Crear nuevos usuarios
- Editar perfiles existentes
- Asignar roles y permisos
- Activar/desactivar usuarios

### Configuración:
- Ajustes generales del sistema
- Configuración de seguridad
- Gestión de notificaciones
- Administración de almacenamiento

## 🧪 Testing

```bash
# Ejecutar tests
npm run test

# Ejecutar tests con coverage
npm run test:coverage

# Ejecutar tests en modo watch
npm run test:watch
```

## 🚀 Deployment

### Build de Producción:
```bash
npm run build
```

### Archivos Generados:
- `dist/`: Archivos optimizados para producción
- Assets estáticos con hash para caché
- HTML, CSS y JS minificados

## 🤝 Contribuir

1. Fork el repositorio
2. Crea una rama para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. Commit tus cambios (`git commit -m 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

## ✨ Características Destacadas

- **Zero Configuration**: Funciona sin configuración adicional
- **Type Safety**: TypeScript para desarrollo robusto
- **Performance**: Optimizado para rendimiento
- **Accessibility**: Cumple con estándares de accesibilidad
- **Cross-Platform**: Compatible con todos los navegadores modernos

## 🐛 Reportar Problemas

Si encuentras algún problema o tienes sugerencias:

1. Revisa los [issues existentes](../../issues)
2. Crea un nuevo issue con descripción detallada
3. Incluye pasos para reproducir el problema
4. Añade capturas de pantalla si es necesario

---

**Desarrollado con ❤️ para la gestión eficiente de compras emergentes**
